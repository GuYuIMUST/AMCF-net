import pandas as pd

a = pd.read_csv('../data/annotationdetclsconvfnl_v3.csv')
path = 'F:\\医学数据集\\LUNA\\rowfile\\subset5'