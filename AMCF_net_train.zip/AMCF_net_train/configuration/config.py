import numpy as np

class config:
    def __init__(self, channel_range):