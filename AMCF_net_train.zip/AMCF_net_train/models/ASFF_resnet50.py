import torch
import torch.nn as nn
import torch.nn.functional as F
from  models.daf_resnet50_3d_yuan import resnet50


class ASFF(nn.Module):
    def __init__(self, level, in_channels):
        super(ASFF, self).__init__()
        self.level = level
        self.dim = [in_channels // 4, in_channels // 8, in_channels // 16]
        self.inter_dim = self.dim[self.level]

        self.compress_level_0 = nn.Conv3d(in_channels, self.inter_dim, kernel_size=1, stride=1)
        self.compress_level_1 = nn.Conv3d(in_channels, self.inter_dim, kernel_size=1, stride=1)
        self.compress_level_2 = nn.Conv3d(in_channels, self.inter_dim, kernel_size=1, stride=1)

        self.stride_level_1 = nn.Conv3d(in_channels, self.inter_dim, kernel_size=3, stride=2, padding=1)
        self.stride_level_2 = nn.Conv3d(in_channels, self.inter_dim, kernel_size=3, stride=2, padding=1)

        self.expand = nn.Conv3d(self.inter_dim, in_channels, kernel_size=3, stride=1, padding=1)

        self.weight_level_0 = nn.Conv3d(self.inter_dim, 1, kernel_size=1, stride=1)
        self.weight_level_1 = nn.Conv3d(self.inter_dim, 1, kernel_size=1, stride=1)
        self.weight_level_2 = nn.Conv3d(self.inter_dim, 1, kernel_size=1, stride=1)

        self.weight_levels = nn.Conv3d(3, 3, kernel_size=1, stride=1, padding=0)

    def forward(self, x_level_0, x_level_1, x_level_2):
        level_0_compressed = self.compress_level_0(x_level_0)
        level_1_compressed = self.compress_level_1(x_level_1)
        level_2_compressed = self.compress_level_2(x_level_2)

        level_0_resized = level_0_compressed
        level_1_resized = self.stride_level_1(level_1_compressed)
        level_2_resized = self.stride_level_2(level_2_compressed)

        level_0_weight_v = self.weight_level_0(level_0_resized)
        level_1_weight_v = self.weight_level_1(level_1_resized)
        level_2_weight_v = self.weight_level_2(level_2_resized)
        levels_weight_v = torch.cat((level_0_weight_v, level_1_weight_v, level_2_weight_v), 1)
        levels_weight = self.weight_levels(levels_weight_v)
        levels_weight = F.softmax(levels_weight, dim=1)

        fused_out_reduced = level_0_resized * levels_weight[:, 0:1, :, :] + \
                            level_1_resized * levels_weight[:, 1:2, :, :] + \
                            level_2_resized * levels_weight[:, 2:, :, :]

        out = self.expand(fused_out_reduced)

        return out


class ResNet50_ASFF(nn.Module):
    def __init__(self):
        super(ResNet50_ASFF, self).__init__()
        self.resnet = resnet50()
        self.layer1 = self.resnet.layer1
        self.layer2 = self.resnet.layer2
        self.layer3 = self.resnet.layer3
        self.layer4 = self.resnet.layer4

        self.asff_level1 = ASFF(level=0, in_channels=256)
        self.asff_level2 = ASFF(level=1, in_channels=512)
        self.asff_level3 = ASFF(level=2, in_channels=1024)

        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(2048,2)  # Replace num_classes with the number of your classification classes

    def forward(self, x):
        x = self.resnet.conv1(x)
        x = self.resnet.bn1(x)
        x = self.resnet.relu(x)
        x = self.resnet.maxpool(x)

        x = self.layer1(x)
        level1_out = self.asff_level1(x, x, x)

        x = self.layer2(level1_out)
        level2_out = self.asff_level2(level1_out, x, x)

        x = self.layer3(level2_out)
        level3_out = self.asff_level3(level2_out, x, x)

        x = self.layer4(level3_out)

        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)

        return x
if __name__ == '__main__':
    import os

    os.environ['CUDA_VISIBLE_DEVICES'] = "1,0"
    img = torch.rand(2, 1, 32, 32, 32).cuda()  # guyu
    net = ResNet50_ASFF().cuda().train()
    result = net(img)  # liu
    print(result.shape)  # wang [2,2]