import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.models.layers import trunc_normal_, DropPath
from timm.models.registry import register_model
# from models.fusion_3d import AFF, iAFF, DAF, NonLocal
print(torch.cuda.is_available())# W ,程序报错，RuntimeError: No CUDA GPUs are available，所以才在这加的


def build_act_layer(act_type):  # W 创建激活层
    """Build activation layer."""
    if act_type is None:
        return nn.Identity()
    assert act_type in ['GELU', 'ReLU', 'SiLU']
    if act_type == 'SiLU':
        return nn.SiLU()  # W，3D直接可以用
    elif act_type == 'ReLU':
        return nn.ReLU()# W，3D直接可以用
    else:
        return nn.GELU() # W GELU直接3D可以使用


def build_norm_layer(norm_type, embed_dims): # W ，创建归一化层
    """Build normalization layer."""
    assert norm_type in ['BN', 'GN', 'LN2d', 'SyncBN']
    if norm_type == 'GN':
        return nn.GroupNorm(embed_dims, embed_dims, eps=1e-5)
    if norm_type == 'LN2d':
        return LayerNorm(embed_dims, eps=1e-6) # W，self.LN1 = LayerNorm([64, 32], eps=1e-6, data_format="channels_first")，输入通道数和feature map 的大小
    if norm_type == 'SyncBN':
        return nn.SyncBatchNorm(embed_dims, eps=1e-5)
    else:
        return nn.BatchNorm3d(embed_dims, eps=1e-5) # W，换成了3D


# class LayerNorm2d(nn.Module):
#     r""" LayerNorm that supports two data formats: channels_last (default) or channels_first.
#     The ordering of the dimensions in the inputs. channels_last corresponds to inputs with
#     shape (batch_size, height, width, channels) while channels_first corresponds to inputs
#     with shape (batch_size, channels, height, width).
#     """
#     def __init__(self,
#                  normalized_shape,
#                  eps=1e-6,
#                  data_format="channels_last"):
#         super().__init__()
#         self.weight = nn.Parameter(torch.ones(normalized_shape))
#         self.bias = nn.Parameter(torch.zeros(normalized_shape))
#         self.eps = eps
#         self.data_format = data_format
#         assert self.data_format in ["channels_last", "channels_first"]
#         self.normalized_shape = (normalized_shape, )
#
#     def forward(self, x):
#         if self.data_format == "channels_last":
#             return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
#         elif self.data_format == "channels_first":
#             u = x.mean(1, keepdim=True)
#             s = (x - u).pow(2).mean(1, keepdim=True)
#             x = (x - u) / torch.sqrt(s + self.eps)
#             x = self.weight[:, None, None] * x + self.bias[:, None, None]
#             return x
class LayerNorm(nn.Module):
    r""" LayerNorm that supports two data formats: channels_last (default) or channels_first.
    The ordering of the dimensions in the inputs. channels_last corresponds to inputs with
    shape (batch_size, height, width, channels) while channels_first corresponds to inputs
    with shape (batch_size, channels, height, width).
    """

    def __init__(self, normalized_shape, eps=1e-6, data_format="channels_last"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.data_format = data_format
        if self.data_format not in ["channels_last", "channels_first"]:
            raise NotImplementedError
        self.normalized_shape = (normalized_shape,)

    def forward(self, x): # W ，Layernorm
        if self.data_format == "channels_last":
            return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        elif self.data_format == "channels_first":
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            x = self.weight[:, None, None] * x + self.bias[:, None, None]
            return x


class ElementScale(nn.Module): # W，不知道这块要不要改成3D的，目前感觉不用改！！！这块就是乘以对应的参数
    """A learnable element-wise scaler.一个可学习的基于元素的标量"""

    def __init__(self, embed_dims, init_value=0., requires_grad=True):
        super(ElementScale, self).__init__()
        self.scale = nn.Parameter(  # W，将一个不可训练的tensor转换成可以训练的parameter,并且训练这个parameter，并优化
            #init_value * torch.ones((1, embed_dims, 1, 1)),
            init_value * torch.ones((1, embed_dims, 1, 1,1)),# W ,此处改成3D
            requires_grad=requires_grad
        )

    def forward(self, x):  # W ,ElementScale
        return x * self.scale # W ,x:[2,32,8,8,8],self.scale:[1,32,1,1]


class ChannelAggregationFFN(nn.Module):# W，ChannelAggregation！！！
    """An implementation of FFN with Channel Aggregation.基于信道聚合的FFN实现

    Args:
        embed_dims (int): The feature dimension. Same as
            `MultiheadAttention`.
        feedforward_channels (int): The hidden dimension of FFNs.
        kernel_size (int): The depth-wise conv kernel size as the
            depth-wise convolution. Defaults to 3.
        act_type (str): The type of activation. Defaults to 'GELU'.
        ffn_drop (float, optional): Probability of an element to be
            zeroed in FFN. Default 0.0.
    """

    def __init__(self,
                 embed_dims,# W ,输入通道数
                 feedforward_channels,# W FFN的隐维数
                 kernel_size=3,# W ,DW卷积核的大小
                 act_type='GELU',#
                 ffn_drop=0.):
        super(ChannelAggregationFFN, self).__init__()

        self.embed_dims = embed_dims
        self.feedforward_channels = feedforward_channels
        # W ,就是这块 feedforward_channels=128，出的差错
       #W ，self.fc1 = nn.Conv2d(in_channels=embed_dims,out_channels=self.feedforward_channels,kernel_size=1)
        self.fc1 = nn.Conv3d(in_channels=embed_dims,out_channels=self.feedforward_channels,kernel_size=1)

        # W ，self.dwconv = nn.Conv2d(in_channels=self.feedforward_channels,out_channels=self.feedforward_channels,kernel_size=kernel_size,stride=1,padding=kernel_size // 2,bias=True,groups=self.feedforward_channels)
        self.dwconv = nn.Conv3d(in_channels=self.feedforward_channels,out_channels=self.feedforward_channels,kernel_size=kernel_size,stride=1,padding=kernel_size // 2,bias=True,groups=self.feedforward_channels)

        self.act = build_act_layer(act_type) # W ,创建所选的激活函数GELU

        # W，self.fc2 = nn.Conv2d(in_channels=feedforward_channels,out_channels=embed_dims,kernel_size=1)
        self.fc2 = nn.Conv3d(in_channels=feedforward_channels,out_channels=embed_dims,kernel_size=1)

        # W ,self.drop = nn.Dropout(ffn_drop)# W，为了防止过拟合,神经元全部被激活
        self.drop = nn.Dropout3d(ffn_drop)

        #W,self.decompose = nn.Conv2d(in_channels=self.feedforward_channels,  out_channels=1, kernel_size=1,)
        self.decompose = nn.Conv3d(in_channels=self.feedforward_channels,  out_channels=1, kernel_size=1,)


        self.sigma = ElementScale(
            self.feedforward_channels, init_value=1e-5, requires_grad=True)
        self.decompose_act = build_act_layer(act_type)# W ,创建所选的激活函数GELU

    def feat_decompose(self, x):# W，Channel Aggregation,这块应该不用改3D
        # x_d: [B, C, H, W] -> [B, 1, H, W]
        x = x + self.sigma(x - self.decompose_act(self.decompose(x)))# W，经过卷积＋激活函数
        return x

    def forward(self, x):# W，Channel Aggregation
        # proj 1  # W，这块好像少了一个图中norm
        x = self.fc1(x) # W，1*1卷积
        x = self.dwconv(x) # W，3*3卷积
        x = self.act(x) # W，经过GELU激活函数
        x = self.drop(x) # W，此处不知道为啥经过self.drop
        # proj 2
        x = self.feat_decompose(x)# W，Channel Aggregation，这块注释掉了
        x = self.fc2(x) # W，经过1*1卷积
        x = self.drop(x)
        return x # W ,stage1,经过第一个channel Aggregation后：x[2,32,8,8,8],stage2经过第一个channel后x:[2,64,4,4,4];stage3经过第一个channel后x:[2,128,2,2,2]；stage4经过第一个channel后x:[2,256,1,1,1]


class MultiOrderDWConv(nn.Module):# W ,DW卷积，在后面有调用
    """Multi-order Features with Dilated DWConv Kernel.

    Args:
        embed_dims (int): Number of input channels.输入通道数
        dw_dilation (list): Dilations of three DWConv layers.三个DWConv层的扩张
        channel_split (list): The raletive ratio of three splited channels.三个分离通道的相对比率
    """

    def __init__(self,
                 embed_dims,
                 dw_dilation=[1, 2, 3,],
                 channel_split=[1, 3, 4,],
                ):
        super(MultiOrderDWConv, self).__init__()

        self.split_ratio = [i / sum(channel_split) for i in channel_split]
        self.embed_dims_1 = int(self.split_ratio[1] * embed_dims)
        self.embed_dims_2 = int(self.split_ratio[2] * embed_dims)
        self.embed_dims_0 = embed_dims - self.embed_dims_1 - self.embed_dims_2
        self.embed_dims = embed_dims
        assert len(dw_dilation) == len(channel_split) == 3
        assert 1 <= min(dw_dilation) and max(dw_dilation) <= 3
        # W ，这句话的意思是embed_dim对于channel_split取余不能是0，也就是embed_dims不能是8的整数倍
        # W，这块注释掉代码就可以debug,但是当不注释掉的话就debug不了，所以这块的问题得解决
        # W ,当设置group_width=8 or 16的时候必须将198行注释掉
       # assert embed_dims % sum(channel_split) == 0

        # W
        # basic DW conv
        # self.DW_conv0 = nn.Conv2d(
        #     in_channels=self.embed_dims,
        #     out_channels=self.embed_dims,
        #     kernel_size=5,
        #     padding=(1 + 4 * dw_dilation[0]) // 2,
        #     groups=self.embed_dims,
        #     stride=1, dilation=dw_dilation[0],
        # )
        self.DW_conv0 = nn.Conv3d(
            in_channels=self.embed_dims,
            out_channels=self.embed_dims,
            kernel_size=5,
            padding=(1 + 4 * dw_dilation[0]) // 2,
            groups=self.embed_dims,
            stride=1, dilation=dw_dilation[0],
        )
        # W
        # DW conv 1
        # self.DW_conv1 = nn.Conv2d(
        #     in_channels=self.embed_dims_1,
        #     out_channels=self.embed_dims_1,
        #     kernel_size=5,
        #     padding=(1 + 4 * dw_dilation[1]) // 2,
        #     groups=self.embed_dims_1,
        #     stride=1, dilation=dw_dilation[1],
        # )
        self.DW_conv1 = nn.Conv3d(
            in_channels=self.embed_dims_1,
            out_channels=self.embed_dims_1,
            kernel_size=5,
            padding=(1 + 4 * dw_dilation[1]) // 2,
            groups=self.embed_dims_1,
            stride=1, dilation=dw_dilation[1],
        )
        # W
        # DW conv 2
        # self.DW_conv2 = nn.Conv2d(
        #     in_channels=self.embed_dims_2,
        #     out_channels=self.embed_dims_2,
        #     kernel_size=7,
        #     padding=(1 + 6 * dw_dilation[2]) // 2,
        #     groups=self.embed_dims_2,
        #     stride=1, dilation=dw_dilation[2],
        # )
        self.DW_conv2 = nn.Conv3d(
            in_channels=self.embed_dims_2,
            out_channels=self.embed_dims_2,
            kernel_size=7,
            padding=(1 + 6 * dw_dilation[2]) // 2,
            # W ,DW卷积里面也有一个groups，不知道两者的含义是否一样
            groups=self.embed_dims_2,
            stride=1, dilation=dw_dilation[2],
        )
        # W
        # a channel convolution
        # self.PW_conv = nn.Conv2d(  # point-wise convolution
        #     in_channels=embed_dims,
        #     out_channels=embed_dims,
        #     kernel_size=1)
        self.PW_conv = nn.Conv3d(  # point-wise convolution
            in_channels=embed_dims,
            out_channels=embed_dims,
            kernel_size=1)

    def forward(self, x): # W ,DW
        x_0 = self.DW_conv0(x)
        x_1 = self.DW_conv1(
            x_0[:, self.embed_dims_0: self.embed_dims_0+self.embed_dims_1, ...])
        x_2 = self.DW_conv2(
            x_0[:, self.embed_dims-self.embed_dims_2:, ...])
        x = torch.cat([
            x_0[:, :self.embed_dims_0, ...], x_1, x_2], dim=1)
        x = self.PW_conv(x)
        return x


class MultiOrderGatedAggregation(nn.Module):# W，SMixer，对应的是spatial aggregation block
    """Spatial Block with Multi-order Gated Aggregation.

    Args:
        embed_dims (int): Number of input channels.
        attn_dw_dilation (list): Dilations of three DWConv layers.
        attn_channel_split (list): The raletive ratio of splited channels.
        attn_act_type (str): The activation type for Spatial Block.
            Defaults to 'SiLU'.
    """

    def __init__(self,
                 embed_dims,
                 attn_dw_dilation=[1, 2, 3],
                 attn_channel_split=[1, 3, 4],
                 attn_act_type='SiLU',
                 attn_force_fp32=False,
                ):
        super(MultiOrderGatedAggregation, self).__init__()

        self.embed_dims = embed_dims
        self.attn_force_fp32 = attn_force_fp32 # W ,MogaNet调用MogaBlock,MogaBlock调用此模块的时候attn_force_fp32=True
        # W
        # self.proj_1 = nn.Conv2d(in_channels=embed_dims, out_channels=embed_dims, kernel_size=1)
        self.proj_1 = nn.Conv3d(in_channels=embed_dims, out_channels=embed_dims, kernel_size=1)

        # W
       # self.gate = nn.Conv2d(in_channels=embed_dims, out_channels=embed_dims, kernel_size=1)
        self.gate = nn.Conv3d(in_channels=embed_dims, out_channels=embed_dims, kernel_size=1)

        self.value = MultiOrderDWConv(
            embed_dims=embed_dims,
            dw_dilation=attn_dw_dilation,
            channel_split=attn_channel_split,
        )

        # W
        #self.proj_2 = nn.Conv2d(in_channels=embed_dims, out_channels=embed_dims, kernel_size=1)
        self.proj_2 = nn.Conv3d(in_channels=embed_dims, out_channels=embed_dims, kernel_size=1)

        # activation for gating and value
        self.act_value = build_act_layer(attn_act_type)# W ,创建所选的激活函数SiLU
        self.act_gate = build_act_layer(attn_act_type)# W ,创建所选的激活函数SiLU

        # decompose 分解
        # W，应该就是一个参数gama,用在程序当中
        self.sigma = ElementScale(
            embed_dims, init_value=1e-5, requires_grad=True)
    # W，这部分是Multi-Order Gated Aggregation的上一部分的代码
    def feat_decompose(self, x):# W ,spatial aggregation
        x = self.proj_1(x)# W 1*1卷积
        # x_d: [B, C, H, W] -> [B, C, 1, 1]
        #x_d = F.adaptive_avg_pool2d(x, output_size=1)
        x_d = F.adaptive_avg_pool3d(x, output_size=1) # W [B,C,D,H,W]
        x = x + self.sigma(x - x_d) # W subtract，此处乘以的是γs
        x = self.act_value(x) # W 经过GELU激活函数
        return x

    def forward_gating(self, g, v):
        #with torch.autocast(device_type='cuda', enabled=False):
        with torch.cuda.amp.autocast(enabled=False):  # W ,这块稍作修改，目的是解决程序的报错
            g = g.to(torch.float32)
            v = v.to(torch.float32)
            return self.proj_2(self.act_gate(g) * self.act_gate(v))

    def forward(self, x): # W， spatial aggregation
        shortcut = x.clone()
        # proj 1x1
        x = self.feat_decompose(x)

        # gating and value branch # W ,把这块先注释掉看是否加快网络的训练速度
        g = self.gate(x) # W，进行普通1*1卷积
        v = self.value(x)# W，进行DW卷积
        # aggregation聚合
        if not self.attn_force_fp32:# W，走这条路
            x = self.proj_2(self.act_gate(g) * self.act_gate(v)) # W g和v经过SiLU之后通过卷积
        else:
            x = self.forward_gating(self.act_gate(g), self.act_gate(v)) # W 把g和v变成tensor之后，g和v经过SiLU之后通过卷
        x = x + shortcut
        return x # W，stage1：第一次经过Spatial的x:[2,32,8,8,8],stage2,第一次经过Spatial的x:[2,64,4,4,4],stage3第一次经过Spatial的x:[2,128,2,2,2]；stage4第一次经过Spatial的x:[2,256,1,1,1]


class MogaBlock(nn.Module):
    """A block of MogaNet.

    Args:
        embed_dims (int): Number of input channels.
        ffn_ratio (float): The expansion ratio of feedforward network hidden
            layer channels. Defaults to 4.
        drop_rate (float): Dropout rate after embedding. Defaults to 0.
        drop_path_rate (float): Stochastic depth rate. Defaults to 0.1.
        act_type (str): The activation type for projections and FFNs.
            Defaults to 'GELU'.
        norm_cfg (str): The type of normalization layer. Defaults to 'BN'.
        init_value (float): Init value for Layer Scale. Defaults to 1e-5.
        attn_dw_dilation (list): Dilations of three DWConv layers.
        attn_channel_split (list): The raletive ratio of splited channels.
        attn_act_type (str): The activation type for the gating branch.
            Defaults to 'SiLU'.
    """

    def __init__(self,
                 embed_dims,
                 # W ,stage的forward函数里面的self.base传参的时候应该把这个参数传进来了，但是还是执行的是默认的4
                 ffn_ratio=8.,# W ,这块更改对于出错没影响，可能在调用MogaBlock的时候已经对其进行更改
                 drop_rate=0.,
                 drop_path_rate=0.,
                 act_type='GELU',
                 norm_type='BN',
                 init_value=1e-5,
                 attn_dw_dilation=[1, 2, 3],
                 attn_channel_split=[1, 3, 4],
                 attn_act_type='SiLU',
                 attn_force_fp32=False,
                ):
        super(MogaBlock, self).__init__()
        self.out_channels = embed_dims

        self.norm1 = build_norm_layer(norm_type, embed_dims)# W ,创建所选的归一化方式BN,MogaNet调用此模块的时候norm_type=BN

        # spatial attention
        self.attn = MultiOrderGatedAggregation(
            embed_dims,
            attn_dw_dilation=attn_dw_dilation, # W，MogaNet调用此模块模块的时候attn_dw_dilation=[1, 2, 3]
            attn_channel_split=attn_channel_split,# W ,MogaNet调用此模块模块的时候attn_channel_split=[1, 3, 4]
            attn_act_type=attn_act_type, # W ,MogaNet调用此模块模块的时候attn_act_type=SiLU
            attn_force_fp32=attn_force_fp32, # W ,MogaNet调用此模块的时候attn_force_fp32=True
        )
        self.drop_path = DropPath(  # W，这块应该本来就是3D的，应该不用改
            drop_path_rate) if drop_path_rate > 0. else nn.Identity() # W ,MogaNet调用此模块的时候drop_path_rate=0

        self.norm2 = build_norm_layer(norm_type, embed_dims)# W ,创建所选的归一化方式,# W ,创建所选的归一化方式BN,MogaNet调用此模块的时候norm_type=BN

        # channel MLP
        mlp_hidden_dim = int(embed_dims * ffn_ratio) # W ,=int(embed_dims*4)
        self.mlp = ChannelAggregationFFN(  # DWConv + Channel Aggregation FFN
            embed_dims=embed_dims, # W,输入通道数
            feedforward_channels=mlp_hidden_dim,# W，# W FFN的隐维数
            act_type=act_type,# W ,MogaNet调用此模块的时候attn_act_type=SiLU
            ffn_drop=drop_rate,# W，0
        )

        # init layer scale
        #self.layer_scale_1 = nn.Parameter(init_value * torch.ones((1, embed_dims, 1, 1)), requires_grad=True) # W ,不知道这块要不要改成
        self.layer_scale_1 = nn.Parameter(init_value * torch.ones((1, embed_dims, 1, 1,1)), requires_grad=True)

        #self.layer_scale_2 = nn.Parameter(init_value * torch.ones((1, embed_dims, 1, 1)), requires_grad=True)
        self.layer_scale_2 = nn.Parameter(init_value * torch.ones((1, embed_dims, 1, 1,1)), requires_grad=True)

    def forward(self, x): # W ，MogaBlock
        # spatial


        identity = x # W x:[2,32,8,8,8]
        # W，程序运行到这的时候根本不进spital里面的forward函数，导致这种情况发生的原因是什么呢？？？，报错显示的是self.norm1(x)里面应该传入32个通道，但是现在输入的通道数是256，这个256来的原因是什么？
       # W，那难道是输入的embed_channel变成了256？？？
        # W ,目前出错的原因是在e调用MogaBlock的时候，出现了维度不匹配的问题，猜测的原因可能是raw_planes与cheap_planes 这块的代码没有弄的很透彻
        x = self.layer_scale_1 * self.attn(self.norm1(x)) # W ，BN
        #print(x)
        x = identity + self.drop_path(x)
        # channel
        identity = x
        x = self.layer_scale_2 * self.mlp(self.norm2(x)) # W ，MogaBlock
        x = identity + self.drop_path(x)
        return x # W ,经过第一个stage后x:[2,32,8,8,8]


class ConvPatchEmbed(nn.Module):
    """An implementation of Conv patch embedding layer.# W，Conv补丁嵌入层的实现

    Args:
        in_features (int): The feature dimension.
        embed_dims (int): The output dimension of PatchEmbed.
        kernel_size (int): The conv kernel size of PatchEmbed. 
            Defaults to 3.
        stride (int): The conv stride of PatchEmbed. Defaults to 2.
        norm_type (str): The type of normalization layer. Defaults to 'BN'.
    """

    def __init__(self,
                 in_channels,
                 embed_dims,
                 kernel_size=3,
                 stride=2,
                 norm_type='BN'):
        super(ConvPatchEmbed, self).__init__()
        # W
        # self.projection = nn.Conv2d(
        #     in_channels, embed_dims, kernel_size=kernel_size,
        #     stride=stride, padding=kernel_size // 2)
        # W，output_size = (input_size + padding * 2 - kernel_size) / stride + 1
        self.projection = nn.Conv3d(
            in_channels, embed_dims, kernel_size=kernel_size,
            stride=stride, padding=kernel_size // 2)

        self.norm = build_norm_layer(norm_type, embed_dims)# W ,创建所选的归一化方式BN

    def forward(self, x):
        x = self.projection(x) # W，卷积操作
        # W，BN
        x = self.norm(x)

        #out_size = (x.shape[2], x.shape[3])# W，不知道这块用不用变一下？？？,同StackConvPatchEmbed一样，加上一个x.shape[4]
        out_size = (x.shape[2], x.shape[3], x.shape[4])

        return x, out_size # W ,stage2,第一次经过的时候x:[2,32,8,8,8],第二次经过的时候x:[2,128,2,2,2];第三经过的时候x:[2,256,1,1,1];


class StackConvPatchEmbed(nn.Module):# W，StackConvPatchEmbed与ConvPatchEmbed的区别是：ConvPatchEmbed只进行3*3的普通卷积，而StackConvPatchEmbed依次进行3*3卷积，归一化，激活函数，3*3卷积，归一化
    """An implementation of Stack Conv patch embedding layer.# W，Stack Conv补丁嵌入层的实现

    Args:
        in_features (int): The feature dimension.
        embed_dims (int): The output dimension of PatchEmbed.
        kernel_size (int): The conv kernel size of stack patch embedding.
            Defaults to 3.
        stride (int): The conv stride of stack patch embedding.
            Defaults to 2.
        act_type (str): The activation in PatchEmbed. Defaults to 'GELU'.
        norm_type (str): The type of normalization layer. Defaults to 'BN'.
    """

    def __init__(self,
                 in_channels,
                 embed_dims,
                 kernel_size=3,
                 stride=2,
                 act_type='GELU',
                 norm_type='BN'):
        super(StackConvPatchEmbed, self).__init__()

        self.projection = nn.Sequential(

            # nn.Conv2d(in_channels, embed_dims // 2, kernel_size=kernel_size,
            #     stride=stride, padding=kernel_size // 2),
            nn.Conv3d(in_channels, embed_dims // 2, kernel_size=kernel_size,
                      stride=stride, padding=kernel_size // 2),

            build_norm_layer(norm_type, embed_dims // 2),# W ,创建所选的归一化方式BN

            build_act_layer(act_type),# W ,创建所选的激活函数GELU
            # nn.Conv2d(embed_dims // 2, embed_dims, kernel_size=kernel_size,
            #     stride=stride, padding=kernel_size // 2),
            # W ,要知道具体的输入输出
            nn.Conv3d(embed_dims // 2, embed_dims, kernel_size=kernel_size,
                      stride=stride, padding=kernel_size // 2),

            build_norm_layer(norm_type, embed_dims),# W ,创建所选的归一化方式BN
        )

    def forward(self, x):
        x = self.projection(x)
        #out_size = (x.shape[2], x.shape[3]) # W，不知道这块用不用变一下？？？,二维的话就是[B,C,H,W]所以输出H，W；要是三维的话就[B,C,D,H,W],所以此处应该是out_size = (x.shape[2], x.shape[3]，x.shape[4])
        out_size = (x.shape[2], x.shape[3],x.shape[4])
        return x, out_size  # stage1的第一个x:[2,32,8,8,8]，out_size:[8,8,8]
    # W，stage的设计应该围绕MogaBlock进行设计


class Stage(nn.Module):# W ，觉得Moganet也需要一个这样的函数，来接受MogaBlock模块之间的Complictied path和Ghost path
    # W ,planes代表的是输出通道数，调用此函数的时候直接给出数值即可
    # W，group_width=1(默认)，但是在Ghost path时不等于1,这个参数必须保留，因为后续有用到
    # W，blocks代表的是[3,3,12,2]里面的一个数（默认的网络是Tiny）
    # W，stride暂时用不到先删除
    # W，调用MogaBlock需要以下参数：估计需要传embed_dims、ffn_ratio 、

    # W ,目前的出错地方是Bottleneck传入输出通道是下一个layer的输入通道，而且数值不一样。但是现在转换到MogaBlock输入和输出的都是一样的，所以对代码应该进行改动

    # embed_dims,
    # ffn_ratio = 4.,
    # drop_rate = 0.,
    # drop_path_rate = 0.,
    # act_type = 'GELU',
    # norm_type = 'BN',
    # init_value = 1e-5,
    # attn_dw_dilation = [1, 2, 3],
    # attn_channel_split = [1, 3, 4],
    # attn_act_type = 'SiLU',
    # attn_force_fp32 = False,
    #
    # MogaBlock(
    #     embed_dims=self.embed_dims[i],  # W ,embed_dims=32,64,128,256,输入通道数
    #     ffn_ratio=self.ffn_ratios[i],  # W，ffn_ratio=8, 8, 4, 4
    #     drop_rate=drop_rate,  # W，0
    #     drop_path_rate=dpr[cur_block_idx + j],
    #     norm_type=conv_norm_type,  # W，BN
    #     init_value=init_value,
    #     attn_dw_dilation=attn_dw_dilation,  # W， attn_dw_dilation=[1, 2, 3]
    #     attn_channel_split=attn_channel_split,  # W，attn_channel_split=[1, 3, 4]
    #     attn_act_type=attn_act_type,  # W， attn_act_type='SiLU'
    #     attn_force_fp32=attn_force_fp32,  # W ，attn_force_fp32=True
    # W ,这块的ffn_ratio到后来要进行改变
    # W,
    # self.layer2 = Stage(block, self.inplanes, widths[1], group_width, layers[1], stride=2,
    #                     dilate=replace_stride_with_dilation[1], cheap_ratio=0.5)
    # W ,dilate=False不知道啥意思，ffn_ratio=8是Mogablock的必须参数
    # self.layer2 = Stage(MogaBlock, in_channels, 64, group_width, 3, dilate=False, cheap_ratio=0.5, ffn_ratio=8)
    # W，这块ffn_ratio可以自己先定义一个，等到真正调用的时候直接赋值即可
    # W ,当layer1的时候各参数的值为：in_channel=32;planes=32;group_width=2;blocks=3;
    # W ,self.layeri = Stage(MogaBlock, self.embed_dims[i], self.embed_dims[i], group_width,  self.depths[i], dilate=False, cheap_ratio=0.5)
    def __init__(self, MogaBlock, in_channel, planes, group_width, blocks, dilate=False, cheap_ratio=0.5,ffn_ratio=8.):
        super(Stage, self).__init__()
        # W ,暂时先不需要定义归一化方式，所以先删除
        # norm_layer = nn.BatchNorm3d
        # downsample = None

        # W，这块不知道有没有用，先留着
        self.dilation = 1
        previous_dilation = self.dilation

        # W，因为dilate=False，所以根本不走这条路（删除）
        # if dilate:
        #     self.dilation *= stride
        #     stride = 1
        # W，这块感觉没用，因为Moganet不存在downsample
        # if stride != 1 or self.inplanes != planes:
        #     downsample = nn.Sequential(
        #         conv1x1(inplanes, planes, stride),
        #         norm_layer(planes),
        #   )
        # W ，需要将block改成MogaBlock,但是里面的参数还需要调整
        # W，输入的通道就是in_channel,这块的ffn_ratio没有传进MogaBlock中
        self.base =MogaBlock(in_channel,ffn_ratio)
        # W ,得看这块的输入通道,进入MogaBlock的时候只需要输入通道数，理论上是对的
        self.end = MogaBlock(planes, ffn_ratio)


        # self.base = block(inplanes, planes, stride, downsample, group_width,
        #                   previous_dilation, norm_layer)
        # self.end = block(planes, planes, group_width=group_width,
        #                  dilation=self.dilation,
        #                  norm_layer=norm_layer)
        # W，以下这几行代码可以不用改\
        # W ,如果程序正确的话， group_width=1
        group_width = int(group_width * 0.75)  # W，也不知道这个网络具体怎样改
        # W，raw_planes = int(32 * (1 - 0.5) / 1)*1=16，cheap_plane16
        # W ,为啥raw_planes=128,那就说明planes=256,那为啥planes=256?明明传入的是32呀
        raw_planes = int(planes * (1 - cheap_ratio) / group_width) * group_width # W ，剩下了一半的通道
        cheap_planes = planes - raw_planes# W ，一半的通道进行cheap操作
        self.cheap_planes = cheap_planes
        self.raw_planes = raw_planes

        # W ，self.merge的定义可以直接使用
        self.merge = nn.Sequential(
            nn.AdaptiveAvgPool3d(1),
            nn.Conv3d(planes + raw_planes * (blocks - 2), cheap_planes,
                      kernel_size=1, stride=1, bias=False),
            nn.BatchNorm3d(cheap_planes),
            nn.ReLU(inplace=True),
            nn.Conv3d(cheap_planes, cheap_planes, kernel_size=1, bias=False),
            nn.BatchNorm3d(cheap_planes),
        )
        # W，self.cheap的定义也可以直接使用
        self.cheap = nn.Sequential(
            nn.Conv3d(cheap_planes, cheap_planes,
                      kernel_size=1, stride=1, bias=False),
            nn.BatchNorm3d(cheap_planes),
        )
        # W，self.cheao_relu可以直接使用
        self.cheap_relu = nn.ReLU(inplace=True)

        # layers = []
        # W ，关于downsample的文章都不能留，因为不涉及
        # downsample = nn.Sequential(
        #     LambdaLayer(lambda x: x[:, :raw_planes])
        # )
        # W，这个layers最终要存储的分别是1,1,10,0数量的Mogablock模块，还得想一想layer4咋样进行训练
        # W ,不知道这块为啥要进行两次layer.append
        layers = []
        # layers.append(MogaBlock(raw_planes,ffn_ratio ))
        inplanes = raw_planes
        for _ in range(2,blocks ):  # W，block指的是bottleneck，blocks指的是[1,3,5,7],这块是2的原因是，刚开始x0已经经过一个Bottleneck了，到blocks-1的原因是最后有一个self-end
            layers.append(MogaBlock(inplanes,ffn_ratio ))

        self.layers = nn.Sequential(*layers)

    def forward(self, input): # W,Stage
        # W，为啥进行到这块的时候程序不自动跳入MogaBlock模块呢？
        x0 = self.base(input) # W，在stage2的时候，x0直接经过bottleneck
        m_list = [x0]
        # W，目前程序卡在这里，在程序的输出的时候此时的self.raw_planes=128,所以导致模型出错
        e = x0[:, :self.raw_planes] # W ,前面应该对raw_planes进行定义
        for l in self.layers: # W，这个layer定义的问题看看Regnet是怎样解决的
            e = l(e)# W ,所谓的e就是经是Block2,Block3.......Blockn的最终输出，也就是论文中的complicated path
            m_list.append(e) # W ,这块之所以将e添加道m_list中的原因是下一步将Block2,Block3.......Blockn   cat起来
        m = torch.cat(m_list, 1) # W ,按列拼接，就是图中的concat操作
        m = self.merge(m) # W ，self.merge的定义

        c = x0[:, self.raw_planes:] # W，再将x0的另一半通道取出
        c = self.cheap_relu(self.cheap(c) + m) # W，经过卷积和归一化的c+m,最终经过Relu激活函数，m是

        x = torch.cat((e, c), 1)
        x = self.end(x)# W，最终经过Bottleneck
        return x


class MogaNet(nn.Module):
    r""" MogaNet
        A PyTorch implement of : `Efficient Multi-order Gated Aggregation
        Network <https://arxiv.org/abs/2211.03295>`_

    Args:
        arch (str): MogaNet architecture choosing from 'tiny', 'small',
            'base' and 'large'. Defaults to 'tiny'.
        in_channels (int): The num of input channels. Defaults to 3.
        num_classes (int): The number of classes for linear classifier.线性分类器的类数
            Defaults to 1000.
        drop_rate (float): Dropout rate after embedding. Defaults to 0.
        drop_path_rate (float): Stochastic depth rate. Defaults to 0.1.
        init_value (float): Init value for Layer Scale. Defaults to 1e-5.
        head_init_scale (float): Rescale init of classifier for high-resolution
            fine-tuning. Defaults to 1.
        patch_sizes (List[int | tuple]): The patch size in patch embeddings.
            Defaults to [3, 3, 3, 3].
        stem_norm_type (str): The type for normalization layer for stems.
            Defaults to 'BN'.
        conv_norm_type (str): The type for convolution normalization layer.
            Defaults to 'BN'.
    """
    arch_zoo = {
        **dict.fromkeys(['xt', 'x-tiny'],
                        {'embed_dims': [32, 64, 96, 192],
                         'depths': [3, 3, 10, 2],
                         'ffn_ratios': [8, 8, 4, 4]}),
        **dict.fromkeys(['t', 'tiny'],  # W，要搞清楚这几个参数具体是啥意思
                        {'embed_dims': [32, 64, 128, 256],# W ，输入通道数
                         'depths': [3, 3, 12, 2],# W ，每个stage对应的MogaBlock数量，一个MogaBlock由spatial和channel构成
                         'ffn_ratios': [8, 8, 4, 4]}),
        **dict.fromkeys(['s', 'small'],
                        {'embed_dims': [64, 128, 320, 512],
                         'depths': [2, 3, 12, 2],
                         'ffn_ratios': [8, 8, 4, 4]}),
        **dict.fromkeys(['b', 'base'],
                        {'embed_dims': [64, 160, 320, 512],
                         'depths': [4, 6, 22, 3],
                        'ffn_ratios': [8, 8, 4, 4]}),
        **dict.fromkeys(['l', 'large'],
                        {'embed_dims': [64, 160, 320, 640],
                         'depths': [4, 6, 44, 4],
                         'ffn_ratios': [8, 8, 4, 4]}),
    }  # yapf: disable

    def __init__(self, # W，可以自定义参数
                 arch='t',# W 选择MogaNet的类型“tiny”,"large","small"
                 #in_channels=3, # W，输入通道数
                 in_channels=1, # W ，由于程序报错RuntimeError: Given groups=1, weight of size [16, 3, 3, 3, 3], expected input[2, 1, 32, 32, 32] to have 3 channels, but got 1 channels instead，然后在这个地方改成了1
                 num_classes=2,# W 在resnet50中num_classes=2
                # W ,接下来这四行都是一些固定的参数
                 drop_rate=0.,
                 drop_path_rate=0.,
                 init_value=1e-5,
                 head_init_scale=1.,

                 patch_sizes=[3, 3, 3, 3],# W ,补丁嵌入中的补丁大小
                 stem_norm_type='BN',# W ,茎的归一化层的类型，实际上网络用的是LN
                 conv_norm_type='BN',# W,卷积归一化层的类型
                 patchembed_types=['ConvEmbed', 'Conv', 'Conv', 'Conv',],
                 attn_dw_dilation=[1, 2, 3],# W,三个DWConv层的膨胀
                 attn_channel_split=[1, 3, 4],# W,分裂通道的相对比例1/8,3/8,4/8=1/2
                 attn_act_type='SiLU',# W，门控分支的激活类型
                 attn_final_dilation=True,
                 attn_force_fp32=True,
                # W ,因为在stage中用到，所以加上一个参数
                 # W ,这个参数的设置不知道与DW里面的groups有没有啥关联
                 group_width=16,
                 **kwargs):
        super().__init__()

        if isinstance(arch, str):# W ，如果arch的类型是字符串类型，则执行if以下的语句
            arch = arch.lower() # W，把arch所有字符的大写变成小写
            assert arch in set(self.arch_zoo), \
                f'Arch {arch} is not in default archs {set(self.arch_zoo)}'
            self.arch_settings = self.arch_zoo[arch]
        else:
            essential_keys = {'embed_dims', 'depths', 'ffn_ratios'}
            assert isinstance(arch, dict) and set(arch) == essential_keys, \
                f'Custom arch needs a dict with keys {essential_keys}'
            self.arch_settings = arch
        # W，分别取tiny网络设置的一些参数
        self.embed_dims = self.arch_settings['embed_dims']
        self.depths = self.arch_settings['depths'] # W ,[3, 3, 12, 2] # W ,self.depths应该是一个列表
        self.ffn_ratios = self.arch_settings['ffn_ratios'] # W，[8, 8, 4, 4]
        self.num_stages = len(self.depths) # W ，网络一共有四个阶段，self.num_stages=4
        self.attn_force_fp32 = attn_force_fp32 # W，self.attn_force_fp32=True
        self.use_layer_norm = stem_norm_type == 'LN'
        assert len(patchembed_types) == self.num_stages # W，都是代表4个阶段

        # W ,像G-Ghost那样，建立layer，通过layer调用stage,再通过stage调用mogablock，这块应该暂时用不到stride,因为不涉及downsample问题（此处删除了stride参数）
        # W，暂时先将layer1 的输入通道数改为32，经过MogaBlock前后的输入输出通道一样
        # self.layer1=Stage(MogaBlock, 32, 32, group_width, 3,  dilate=False, cheap_ratio=0.5,ffn_ratio=8)
        # self.layer2=Stage(MogaBlock,64, 64, group_width, 3,  dilate=False, cheap_ratio=0.5,ffn_ratio=8)
        # self.layer3=Stage(MogaBlock, 128, 128, group_width, 12,  dilate=False, cheap_ratio=0.5,ffn_ratio=4)
        # self.layer4=Stage(MogaBlock,256, 256, group_width, 2,  dilate=False, cheap_ratio=0.5,ffn_ratio=4)

        total_depth = sum(self.depths)# W ,最后的结果是20？？3+12+3+2？？ total_depth 这个参数后来也没用到，具体不知道这个参数有啥用
        dpr = [
            x.item() for x in torch.linspace(0, drop_path_rate, total_depth) # W，序列生成器
        ]  # stochastic depth decay rule随机深度衰减法则

        cur_block_idx = 0 # W，在后续的程序中用到
        self.layers = nn.ModuleList()
        for i, depth in enumerate(self.depths):# W，enumerate()函数会生成排序号+序号所对应的数值
            if i == 0 and patchembed_types[i] == "ConvEmbed":# W，首先第一条路走这个通道，剩下三条路走else的通道,i=0,1,2,3.depths=[3, 3, 12, 2]
                assert patch_sizes[i] <= 3 # W , patch_sizes=[3, 3, 3, 3]
                patch_embed = StackConvPatchEmbed(
                    in_channels=in_channels,
                    embed_dims=self.embed_dims[i], # W ,输出通道数；self.embed_dims=[32, 64, 128, 256],此时embed_dims=32，PatchEmbed的输出通道数
                    kernel_size=patch_sizes[i],# W，此时kernel_size=3
                    stride=patch_sizes[i] // 2 + 1,# W，此时stride=3//2+1=2
                    act_type='GELU',
                    norm_type=conv_norm_type, # W，BN
                )
            else:
                patch_embed = ConvPatchEmbed(
                    in_channels=in_channels if i == 0 else self.embed_dims[i - 1],# W，将前一个的输出通道数变成此时的输入通道数
                    embed_dims=self.embed_dims[i],
                    kernel_size=patch_sizes[i], # W，在stem阶段，kernel_size=3
                    stride=patch_sizes[i] // 2 + 1, # W，在stem阶段，stride=2
                    norm_type=conv_norm_type) # W，BN

            if i == self.num_stages - 1 and not  attn_final_dilation:# W，attn_final_dilation=True,所以不走这条路
                attn_dw_dilation = [1, 2, 1]
            # blocks = nn.ModuleList([
            #     MogaBlock(
            #         embed_dims=self.embed_dims[i], # W ,embed_dims=32,64,128,256,输入通道数
            #         ffn_ratio=self.ffn_ratios[i], # W，ffn_ratio=8, 8, 4, 4
            #         drop_rate=drop_rate, # W，0
            #         drop_path_rate=dpr[cur_block_idx + j], # W ,看一下这个数值随不随layer层数的改变而改变
            #         norm_type=conv_norm_type,# W，BN
            #         init_value=init_value,
            #         attn_dw_dilation=attn_dw_dilation, # W， attn_dw_dilation=[1, 2, 3]
            #         attn_channel_split=attn_channel_split, # W，attn_channel_split=[1, 3, 4]
            #         attn_act_type=attn_act_type, # W， attn_act_type='SiLU'
            #         attn_force_fp32=attn_force_fp32, # W ，attn_force_fp32=True
            #     ) for j in range(depth) # W，当depth=3的时候，j的范围（0，3）；当depth=3的时候，j的范围（0，3）；当depth=12的时候，j的范围（0，12）；当depth=2的时候，j的范围（0，2）
            # ])
            # W ,这块的ffn_ratio应该是一个list，所以把它换成list,但是现在报错依然没解决 +
            layeri = Stage(MogaBlock, self.embed_dims[i], self.embed_dims[i], group_width,  self.depths[i], dilate=False, cheap_ratio=0.5,ffn_ratio=self.ffn_ratios[i])
            self.layers.append(layeri)
            #self.layer2 = Stage(MogaBlock, 64, 64, group_width, 3, dilate=False, cheap_ratio=0.5, ffn_ratio=8)


            cur_block_idx += depth # W， cur_block_idx=3+3+12+2=20，这个参数后面也没用到
            norm = build_norm_layer(stem_norm_type, self.embed_dims[i])# W ,创建所选的归一化方式LN，这块看能不能把layernorm改成nn.module里面的3D代码

            self.add_module(f'patch_embed{i + 1}', patch_embed)
            #self.add_module(f'blocks{i + 1}', blocks)
            self.add_module(f'norm{i + 1}', norm)
            # self.fuse_mode = NonLocal(in_channels=self.embed_dims[i], inter_channels=None, sub_sample=False,
            #                           bn_layer=False)  # W in_channels输入通道数
        self.head = nn.Linear(self.embed_dims[-1], num_classes) # W，全连接层：self.head=nn.Linear(256,1000),输入通道数256，输出类别1000

        self.apply(self._init_weights)  # W，初始化权重
        self.head.weight.data.mul_(head_init_scale) # W，head_init_scale=1.
        self.head.bias.data.mul_(head_init_scale)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, (nn.BatchNorm2d, nn.LayerNorm)):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def freeze_patch_emb(self):
        self.patch_embed1.requires_grad = False

    @torch.jit.ignore
    def no_weight_decay(self):
        return dict()

    def get_classifier(self):
        return self.head

    def reset_classifier(self, num_classes, global_pool=''):
        self.num_classes = num_classes
        self.head = nn.Linear(
            self.embed_dims[-1], num_classes) if num_classes > 0 else nn.Identity()

    def forward_features(self, x): # W ,MogaNet
        for i in range(self.num_stages): # W，i=0，1，2，3
            # W，分别取出patch_embed，blocks，norm的值
            patch_embed = getattr(self, f'patch_embed{i + 1}') # W，getattr()是取出对应属性的值,StackConvPatchEmbed和ConvPatchEmbed，第一个用StackConvPatchEmbed，第二个用ConvPatchEmbed
            #blocks = getattr(self, f'blocks{i + 1}')  # W，MogaBlock里面的Channel和Spatial，不同的i对应不同的blocks数量
            norm = getattr(self, f'norm{i + 1}') # W ,所对应的归一化形式

            x, hw_shape = patch_embed(x) # W ,hw_sahpe:[8,8,8]，这块有点不懂这个含义
            # W ，这块应该直接到stage，再有stage到MogaBlock,在stage的时候得调用MogaBlock模块
            # W，所以进行改动
            # for block in blocks:  # W ,这句应该修改，里面应该包含block字样
            #     # x = block(x)
            #     x = Stage(x)

            # W ,这块应该是对的，执行完conv_embed之后进入layer几，然后进入到stage里面进行几次MogaBlock的执行
            x=self.layers[i](x)

            if self.use_layer_norm:# W ,执行这条路，本文压根没用LN
                x = x.flatten(2).transpose(1, 2) # W，此时x=[B,C,H,W],x.x.flatten(2)=[B,C,H*W],再transpose之后，x=[B,H*W,C];如果要是3D的话应该x=[B,C,D，H，W]，所以此时应该改成x.flatten(2)=[B,C,D*H*W],所以说此时这块对三维也同样适用
                x = norm(x) # W，经过LN
                # W ,将block.out_channel改成x[1],等到调代码的时候看一下，这块好像改不改都行，因为执行代码的时候根本不走这条路
                x = x.reshape(-1, *hw_shape,
                              block.out_channels).permute(0, 3, 1, 2).contiguous() # W，这块不知道结果是啥？？？这块应该是对结果的重现调序
            else:
                x = norm(x)
        # x = self.fuse_mode(x)
        #return x.mean(dim=[2, 3])
        return x.mean(dim=[2, 3,4])# W，对特征图的大小取均值
    def forward(self, x): # W ,MogaNet
        x = self.forward_features(x) # W，最终输出的x:[2,256]
        x = self.head(x) # W，经过nn.Linear全连接层后的x[2,2]

        return x


model_urls = {
    "moganet_xtiny_1k": "",
    "moganet_tiny_1k": "",
    "moganet_tiny_1k_sz256": "",
    "moganet_small_1k": "",
    "moganet_base_1k": "",
    "moganet_large_1k": "",
}

# W，应该从下面的网络中选出其中一个
@register_model
def moganet_xtiny(pretrained=False, **kwargs):
    model = MogaNet(arch='x-tiny', **kwargs)
    if pretrained:
        url = model_urls['moganet_xtiny_1k']
        checkpoint = torch.hub.load_state_dict_from_url(url=url, map_location="cpu", check_hash=True)
        model.load_state_dict(checkpoint["state_dict"])
    return model

@register_model
def moganet_tiny(pretrained=False, **kwargs):
    model = MogaNet(arch='tiny', **kwargs)
    if pretrained:
        url = model_urls['moganet_tiny_1k']
        checkpoint = torch.hub.load_state_dict_from_url(url=url, map_location="cpu", check_hash=True)
        model.load_state_dict(checkpoint["state_dict"])
    return model

@register_model
def moganet_tiny_sz256(pretrained=False, **kwargs):
    model = MogaNet(arch='tiny', **kwargs)
    if pretrained:
        url = model_urls['moganet_tiny_1k_sz256']
        checkpoint = torch.hub.load_state_dict_from_url(url=url, map_location="cpu", check_hash=True)
        model.load_state_dict(checkpoint["state_dict"])
    return model

@register_model
def moganet_small(pretrained=False, **kwargs):
    model = MogaNet(arch='small', **kwargs)
    if pretrained:
        url = model_urls['moganet_small_1k']
        checkpoint = torch.hub.load_state_dict_from_url(url=url, map_location="cpu", check_hash=True)
        model.load_state_dict(checkpoint["state_dict"])
    return model

@register_model
def moganet_base(pretrained=False, **kwargs):
    model = MogaNet(arch='base', **kwargs)
    if pretrained:
        url = model_urls['moganet_base_1k']
        checkpoint = torch.hub.load_state_dict_from_url(url=url, map_location="cpu", check_hash=True)
        model.load_state_dict(checkpoint["state_dict"])
    return model

@register_model
def moganet_large(pretrained=False, **kwargs):
    model = MogaNet(arch='large', **kwargs)
    if pretrained:
        url = model_urls['moganet_large_1k']
        checkpoint = torch.hub.load_state_dict_from_url(url=url, map_location="cpu", check_hash=True)
        model.load_state_dict(checkpoint["state_dict"])
    return model
class FocalLoss(nn.Module):
    def __init__(self, gamma=2, alpha=None, reduction='mean'):
        super(FocalLoss, self).__init__()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = reduction

    def forward(self, input, target):
        ce_loss = F.cross_entropy(input, target, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = (1 - pt) ** self.gamma * ce_loss

        if self.alpha is not None:
            focal_loss = self.alpha * focal_loss

        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        else:
            return focal_loss
if __name__ == '__main__':
    import os

    os.environ['CUDA_VISIBLE_DEVICES'] = "1,0"
    img = torch.rand(2, 1, 32, 32, 32).cuda()  # guyu
    net = MogaNet().cuda().train()
    result = net(img)  # liu
    print(result.shape)  # wang [2,2]
    # print('-*********************************')
    # for k, v in net.state_dict().items():
    #     print(k, ' :', v.shape)
    # for k, v in moganet_3D.state_dict().items():
    #     print(k, ' :', v.shape)



    # W，增加模型FLOPs和参数量
    # import torch
    # from ptflops.flops_counter import get_model_complexity_info
    #
    # with torch.cuda.device(0):
    #     flops, params = get_model_complexity_info(net, (1, 32, 32, 32), as_strings=True, print_per_layer_stat=True)
    #     print('Flops:  ' + flops)
    #     print('Params: ' + params)
import torch
import torch.nn as nn
import torch.nn.functional as F
class ASFF_3D(nn.Module):
    def __init__(self, level, rfb=False, vis=False):
        super(ASFF_3D, self).__init__()
        self.level = level  # W ,一共有0,1,2三个level
        self.dim = [512, 256, 256]  # 输入通道数
        self.inter_dim = self.dim[self.level]  # 输出通道数
        if level == 0:
            self.stride_level_1 = add_conv(256, self.inter_dim, 3, 2)  # (256,512,3,2)
            self.stride_level_2 = add_conv(256, self.inter_dim, 3, 2)  # (256,512,3,2)
            self.expand = add_conv(self.inter_dim, 1024, 3, 1)  # (512,1024,3,1)
        elif level == 1:
            self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1)  # (512, 256, 1, 1)
            self.stride_level_2 = add_conv(256, self.inter_dim, 3, 2)  # (256, 256, 3, 2)
            self.expand = add_conv(self.inter_dim, 512, 3, 1)  # (256, 512, 3, 1)
        elif level == 2:
            self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1)  # (512, 256, 1, 1)
            self.expand = add_conv(self.inter_dim, 256, 3, 1)  # (256, 256, 3, 1)

        compress_c = 8 if rfb else 16  # 当添加rfb时，使用一半的通道数以节省内存，此时选用16

        self.weight_level_0 = add_conv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_1 = add_conv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_2 = add_conv(self.inter_dim, compress_c, 1, 1)

        self.weight_levels = nn.Conv3d(compress_c*3, 3, kernel_size=1, stride=1, padding=0)
        self.vis = vis  # False

    def forward(self, x_level_0, x_level_1, x_level_2):
        if self.level == 0:
            level_0_resized = x_level_0
            level_1_resized = self.stride_level_1(x_level_1)

            level_2_downsampled_inter = F.max_pool3d(x_level_2, 3, stride=2, padding=1)
            level_2_resized = self.stride_level_2(level_2_downsampled_inter)

        elif self.level == 1:
            level_0_compressed = self.compress_level_0(x_level_0)
            level_0_resized = F.interpolate(level_0_compressed, scale_factor=2, mode='nearest')
            level_1_resized = x_level_1
            level_2_resized = self.stride_level_2(x_level_2)
        elif self.level == 2:
            level_0_compressed = self.compress_level_0(x_level_0)
            level_0_resized = F.interpolate(level_0_compressed, scale_factor=4, mode='nearest')
            level_1_resized = F.interpolate(x_level_1, scale_factor=2, mode='nearest')
            level_2_resized = x_level_2

        level_0_weight_v = self.weight_level_0(level_0_resized)
        level_1_weight_v = self.weight_level_1(level_1_resized)
        level_2_weight_v = self.weight_level_2(level_2_resized)
        levels_weight_v = torch.cat((level_0_weight_v, level_1_weight_v, level_2_weight_v), 1)
        levels_weight = self.weight_levels(levels_weight_v)
        levels_weight = F.softmax(levels_weight, dim=1)

        fused_out_reduced = level_0_resized * levels_weight[:, 0:1, :, :, :] + \
                            level_1_resized * levels_weight[:, 1:2, :, :, :] + \
                            level_2_resized * levels_weight[:, 2:, :, :, :]

        out = self.expand(fused_out_reduced)

        if self.vis:
            return out, levels_weight, fused_out_reduced.sum(dim=1)
        else:
            return out
class ASFF(nn.Module):
    def __init__(self, level, rfb=False, vis=False):
        super(ASFF, self).__init__()
        self.level = level  # W ,论文中一共有0,1,2三个level
        self.dim = [512, 256, 256] # W ,应该是输入通道数
        self.inter_dim = self.dim[self.level] # W，输出通道数
        if level==0:
            self.stride_level_1 = add_conv(256, self.inter_dim, 3, 2)  # W ,(256,512,3,2)
            self.stride_level_2 = add_conv(256, self.inter_dim, 3, 2)  # W ,(256,512,3,2)
            self.expand = add_conv(self.inter_dim, 1024, 3, 1) # W ,(512,1024,3,1)
        elif level==1:
            self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1) # W (512, 256, 1, 1)
            self.stride_level_2 = add_conv(256, self.inter_dim, 3, 2) # W ,(256, 256, 3, 2)
            self.expand = add_conv(self.inter_dim, 512, 3, 1)# W ,(256, 512, 3, 1)
        elif level==2:
            self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1)# W ,(512, 256, 1, 1)
            self.expand = add_conv(self.inter_dim, 256, 3, 1)# W ,(256, 256, 3, 1)

        compress_c = 8 if rfb else 16  #when adding rfb, we use half number of channels to save memory，此时选用16

        self.weight_level_0 = add_conv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_1 = add_conv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_2 = add_conv(self.inter_dim, compress_c, 1, 1)

        self.weight_levels = nn.Conv2d(compress_c*3, 3, kernel_size=1, stride=1, padding=0)
        self.vis= vis  # W，False


    def forward(self, x_level_0, x_level_1, x_level_2):
        if self.level==0:
            level_0_resized = x_level_0
            level_1_resized = self.stride_level_1(x_level_1)

            level_2_downsampled_inter =F.max_pool2d(x_level_2, 3, stride=2, padding=1)
            level_2_resized = self.stride_level_2(level_2_downsampled_inter)

        elif self.level==1:
            level_0_compressed = self.compress_level_0(x_level_0)
            level_0_resized =F.interpolate(level_0_compressed, scale_factor=2, mode='nearest') # W ，改变数组的尺寸大小
            level_1_resized =x_level_1
            level_2_resized =self.stride_level_2(x_level_2)
        elif self.level==2:
            level_0_compressed = self.compress_level_0(x_level_0)
            level_0_resized =F.interpolate(level_0_compressed, scale_factor=4, mode='nearest')
            level_1_resized =F.interpolate(x_level_1, scale_factor=2, mode='nearest')
            level_2_resized =x_level_2

        level_0_weight_v = self.weight_level_0(level_0_resized)
        level_1_weight_v = self.weight_level_1(level_1_resized)
        level_2_weight_v = self.weight_level_2(level_2_resized)
        levels_weight_v = torch.cat((level_0_weight_v, level_1_weight_v, level_2_weight_v),1)
        levels_weight = self.weight_levels(levels_weight_v)
        levels_weight = F.softmax(levels_weight, dim=1)

        fused_out_reduced = level_0_resized * levels_weight[:,0:1,:,:]+\
                            level_1_resized * levels_weight[:,1:2,:,:]+\
                            level_2_resized * levels_weight[:,2:,:,:]

        out = self.expand(fused_out_reduced)

        if self.vis:
            return out, levels_weight, fused_out_reduced.sum(dim=1)
        else: # W ,走这条路
            return out

def add_conv(in_ch, out_ch, ksize, stride, leaky=True): # W ,全文使用的激活函数为leakyRelu.调用add_conv的都经历conv-bn-leakyrelu
    """
    Add a conv2d / batchnorm / leaky ReLU block.
    Args:
        in_ch (int): number channels of  input  convolution layer卷积的输入通道数
        out_ch (int): number of output channels of the convolution layer.卷积层的输出通道数
        ksize (int): kernel size of the convolution layer.卷积核大小
        stride (int): stride of the convolution layer.卷积层步长
    Returns:返回一系列的卷积层
        stage (Sequential) : Sequential layers composing a convolution block.
    """
    stage = nn.Sequential()
    pad = (ksize - 1) // 2
    stage.add_module('conv', nn.Conv3d(in_channels=in_ch,
                                       out_channels=out_ch, kernel_size=ksize, stride=stride,
                                       padding=pad, bias=False))
    stage.add_module('batch_norm', nn.BatchNorm3d(out_ch))
    if leaky:
        stage.add_module('leaky', nn.LeakyReLU(0.1))
    else:
        stage.add_module('relu6', nn.ReLU6(inplace=True))
    return stage