import torch
import torch.nn as nn
import torch.nn.functional as F
class ASFF_3D(nn.Module):
    def __init__(self, level, rfb=False, vis=False):
        super(ASFF_3D, self).__init__()
        self.level = level  # W ,一共有0,1,2三个level
        # self.dim = [64, 128, 256]  # 输入通道数
        self.dim = [32, 64, 128] # W,每层网络的输出通道数
        self.inter_dim = self.dim[self.level]  # 输出通道数
        if level == 0: # W，为什么参数是这个还有待搞清楚
            self.stride_level_1 = add_conv(self.dim[1], self.inter_dim, 3, 2)  # (64,32,3,2)
            self.stride_level_2 = add_conv(self.dim[2], self.inter_dim, 3, 2)  # (128,32,3,2)
            self.expand = add_conv(self.inter_dim, 256, 3, 1)  # (32,256,3,1) # W，这块的256是现改的，然后就能跑过呢
        elif level == 1:
            self.compress_level_0 = add_conv( self.dim[0], self.inter_dim, 1, 1)  # (32, 64, 1, 1)
            self.stride_level_2 = add_conv(self.dim[2], self.inter_dim, 3, 2)  # (128, 64, 3, 2)
            # self.expand = add_conv(self.inter_dim, 512, 3, 1)  # (64, 512, 3, 1) # W，这块为什么是512？
            self.expand = add_conv(self.inter_dim, 256, 3, 1)
        elif level == 2:
            self.compress_level_0 = add_conv(self.dim[0], self.inter_dim, 1, 1)  # (32, 128, 1, 1)
            if self.dim[1] != self.dim[2]:
                self.compress_level_1 = add_conv(self.dim[1],self.inter_dim,1,1) # W，[64,128,1,1]
            self.expand = add_conv(self.inter_dim, 256, 3, 1)  # (128, 256, 3, 1)

        compress_c = 8 if rfb else 16  # 当添加rfb时，使用一半的通道数以节省内存，此时选用16

        self.weight_level_0 = add_conv(self.inter_dim, compress_c, 1, 1) # W ,[32/64/128,16,1,1]
        self.weight_level_1 = add_conv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_2 = add_conv(self.inter_dim, compress_c, 1, 1)

        self.weight_levels = nn.Conv3d(compress_c*3, 3, kernel_size=1, stride=1, padding=0) # W ,in_channels=48;out_channel=3
        self.vis = vis  # False

    def forward(self, x_level_0, x_level_1, x_level_2):
        B = []
        if self.level == 0:
            level_0_resized = x_level_0
             # level_0_resized = F.interpolate(level_0_resized, scale_factor=1/8,mode='nearest')

            level_1_resized = self.stride_level_1(x_level_1) # W，此时的输入通道数和输出通道数都应该是x_level_1
            # print(f"level_1_resized.shape", level_1_resized.shape) # W ,[2, 32, 2, 2, 2]
            level_1_resized=  F.interpolate(level_1_resized, scale_factor=4, mode='nearest')

            level_2_downsampled_inter = F.max_pool3d(x_level_2, 3, stride=2, padding=1)
            # print(f"level_2_downsampled_inter.shape", level_2_downsampled_inter.shape) # [2, 128, 1, 1, 1]
            level_2_resized = self.stride_level_2(level_2_downsampled_inter) # W，self.stride_level_2的输入输出通道数应该是 x_level_2的
            # print(f"level_2_resized.shape", level_2_resized.shape)# W ,[2, 32, 1, 1, 1]
            level_2_resized = F.interpolate(level_2_resized, scale_factor=8, mode='nearest')
        elif self.level == 1:
            level_0_compressed = self.compress_level_0(x_level_0)
            # print(f"level_0_compressed.shape", level_0_compressed.shape)# W ,[2, 64, 8, 8, 8]
            # level_0_resized = F.interpolate(level_0_compressed, scale_factor=2, mode='nearest')
            level_0_resized = F.interpolate(level_0_compressed, scale_factor=1/2, mode='nearest')
            # print(f"level_0_resized.shape", level_0_resized.shape) # W ,[2, 64, 16, 16, 16]
            level_1_resized = x_level_1
            # print(f"level_1_resized.shape", level_1_resized.shape)# W ,[2, 64, 4, 4, 4]


            level_2_resized = self.stride_level_2(x_level_2)
            # print(f"level_2_resized.shape",level_2_resized.shape)# W ,[2, 64, 1, 1, 1]
            level_2_resized= F.interpolate(level_2_resized, scale_factor=4, mode='nearest')

        elif self.level == 2:
            level_0_compressed = self.compress_level_0(x_level_0)
            # print(f"level_0_compressed.shape",level_0_compressed.shape) # [2,128,8,8,8]
            # level_0_resized = F.interpolate(level_0_compressed, scale_factor=4, mode='nearest')
            level_0_resized = F.interpolate(level_0_compressed, scale_factor=1/4, mode='nearest')
            # print(f"level_0_resized.shape", level_0_resized.shape) # [2,128,32,32,32]
            if self.dim[1] != self.dim[2]:
                level_1_compressed = self.compress_level_1(x_level_1)
                # print(f"level_1_compressed.shape", level_1_compressed.shape) #,[2,128,4,4,4]
                level_1_resized = F.interpolate(level_1_compressed, scale_factor=1/2, mode='nearest')
                # print(f"level_1_resized.shape", level_1_resized.shape) # [2,128,8,8,8]
            else:
                level_1_resized = F.interpolate(x_level_1, scale_factor=2, mode='nearest')
            level_2_resized = x_level_2 # [2,128,2,2,2]
        level_0_weight_v = self.weight_level_0(level_0_resized)# W , H_out = (H_in + 2P - K) / S + 1 =(8+2*0-1)/1+1=8
        # print(f"level_0_weight_v.shape",level_0_weight_v.shape)#  [2, 16, 8, 8, 8]，[2, 16, 16, 16, 16]，[2, 16, 32, 32, 32]
        level_1_weight_v = self.weight_level_1(level_1_resized)# W , H_out = (H_in + 2P - K) / S + 1 =(2+2*0-1)/1+1=2
        # print(f"level_1_weight_v.shape", level_1_weight_v.shape)#  [2, 16, 2, 2, 2]，[2, 16, 4, 4, 4],[2, 16, 8, 8, 8]
        level_2_weight_v = self.weight_level_2(level_2_resized)# W , H_out = (H_in + 2P - K) / S + 1 =(1+2*0-1)/1+1=1
        # print(f"level_2_weight_v.shape", level_2_weight_v.shape)#  [2, 16, 1, 1, 1]，[2, 16, 1, 1, 1],[2, 16, 2, 2, 2]
        levels_weight_v = torch.cat((level_0_weight_v, level_1_weight_v, level_2_weight_v), 1) # W ,目前卡在这过不去，因为特征图的尺寸不一样
        levels_weight = self.weight_levels(levels_weight_v)
        levels_weight = F.softmax(levels_weight, dim=1)
        # W ,这块应该就是融合，前面level_0_resized代表的是前面三个level融合后的内容，后面代表alpha，beta，gama
        fused_out_reduced = level_0_resized * levels_weight[:, 0:1, :, :, :] + \
                            level_1_resized * levels_weight[:, 1:2, :, :, :] + \
                            level_2_resized * levels_weight[:, 2:, :, :, :]

        out = self.expand(fused_out_reduced) # W，这个最终的输出就相当于网络最终的输出[8,2]
        # print(f"out.shape",out.shape) [2, 256, 1, 1, 1]
        if self.vis:
            return out, levels_weight, fused_out_reduced.sum(dim=1)
        else:
            B.append(out)
            return B
class ASFF(nn.Module):
    def __init__(self, level, rfb=False, vis=False):
        super(ASFF, self).__init__()
        self.level = level  # W ,论文中一共有0,1,2三个level
        self.dim = [512, 256, 256] # W ,应该是输入通道数
        self.inter_dim = self.dim[self.level] # W，输出通道数
        if level==0:
            self.stride_level_1 = add_conv(256, self.inter_dim, 3, 2)  # W ,(256,512,3,2)
            self.stride_level_2 = add_conv(256, self.inter_dim, 3, 2)  # W ,(256,512,3,2)
            self.expand = add_conv(self.inter_dim, 1024, 3, 1) # W ,(512,1024,3,1)
        elif level==1:
            self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1) # W (512, 256, 1, 1)
            self.stride_level_2 = add_conv(256, self.inter_dim, 3, 2) # W ,(256, 256, 3, 2)
            self.expand = add_conv(self.inter_dim, 512, 3, 1)# W ,(256, 512, 3, 1)
        elif level==2:
            self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1)# W ,(512, 256, 1, 1)
            self.expand = add_conv(self.inter_dim, 256, 3, 1)# W ,(256, 256, 3, 1)

        compress_c = 8 if rfb else 16  #when adding rfb, we use half number of channels to save memory，此时选用16

        self.weight_level_0 = add_conv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_1 = add_conv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_2 = add_conv(self.inter_dim, compress_c, 1, 1)

        self.weight_levels = nn.Conv2d(compress_c*3, 3, kernel_size=1, stride=1, padding=0)
        self.vis= vis  # W，False


    def forward(self, x_level_0, x_level_1, x_level_2):
        if self.level==0:
            level_0_resized = x_level_0
            print(f"level_0_resized.shape",level_0_resized.shape)
            level_1_resized = self.stride_level_1(x_level_1)
            print(f"level_1_resized.shape", level_1_resized.shape)
            level_2_downsampled_inter =F.max_pool2d(x_level_2, 3, stride=2, padding=1)
            level_2_resized = self.stride_level_2(level_2_downsampled_inter)
            print(f"level_2_resized.shape", level_2_resized.shape)
        elif self.level==1:
            level_0_compressed = self.compress_level_0(x_level_0)
            level_0_resized =F.interpolate(level_0_compressed, scale_factor=2, mode='nearest') # W ，改变数组的尺寸大小
            level_1_resized =x_level_1
            level_2_resized =self.stride_level_2(x_level_2)
        elif self.level==2:
            level_0_compressed = self.compress_level_0(x_level_0)
            level_0_resized =F.interpolate(level_0_compressed, scale_factor=4, mode='nearest')
            level_1_resized =F.interpolate(x_level_1, scale_factor=2, mode='nearest')
            level_2_resized =x_level_2

        level_0_weight_v = self.weight_level_0(level_0_resized)
        level_1_weight_v = self.weight_level_1(level_1_resized)
        level_2_weight_v = self.weight_level_2(level_2_resized)
        levels_weight_v = torch.cat((level_0_weight_v, level_1_weight_v, level_2_weight_v),1)
        levels_weight = self.weight_levels(levels_weight_v)
        levels_weight = F.softmax(levels_weight, dim=1)

        fused_out_reduced = level_0_resized * levels_weight[:,0:1,:,:]+\
                            level_1_resized * levels_weight[:,1:2,:,:]+\
                            level_2_resized * levels_weight[:,2:,:,:]

        out = self.expand(fused_out_reduced)

        if self.vis:
            return out, levels_weight, fused_out_reduced.sum(dim=1)
        else: # W ,走这条路
            return out

def add_conv(in_ch, out_ch, ksize, stride, leaky=True): # W ,全文使用的激活函数为leakyRelu.调用add_conv的都经历conv-bn-leakyrelu
    """
    Add a conv2d / batchnorm / leaky ReLU block.
    Args:
        in_ch (int): number channels of  input  convolution layer卷积的输入通道数
        out_ch (int): number of output channels of the convolution layer.卷积层的输出通道数
        ksize (int): kernel size of the convolution layer.卷积核大小
        stride (int): stride of the convolution layer.卷积层步长
    Returns:返回一系列的卷积层
        stage (Sequential) : Sequential layers composing a convolution block.
    """
    stage = nn.Sequential()
    pad = (ksize - 1) // 2
    stage.add_module('conv', nn.Conv3d(in_channels=in_ch,
                                       out_channels=out_ch, kernel_size=ksize, stride=stride,
                                       padding=pad, bias=False))
    stage.add_module('batch_norm', nn.BatchNorm3d(out_ch))
    if leaky:
        stage.add_module('leaky', nn.LeakyReLU(0.1))
    else:
        stage.add_module('relu6', nn.ReLU6(inplace=True))
    return stage