import torch
import torch.nn as nn
import torch.nn.functional as F
class SEModule(nn.Module):
    def __init__(self, channels, reduction):
        super(SEModule, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool3d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(channels // reduction, channels),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _,_ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1,1)
        # print(y)
        return x * y

# 定义四个特征图的形状[64, 160, 320, 512]
feature_map1 = torch.randn([2, 64, 1, 1, 1])
feature_map2 = torch.randn([2, 160, 1, 1, 1])
feature_map3 = torch.randn([2, 320, 1, 1, 1])
feature_map4 = torch.randn([2, 512, 1, 1, 1])

# 创建SE模块实例
se_module = SEModule(160+64+320+512, reduction=16)

# 将四个特征图按通道拼接在一起
concatenated_features = torch.cat((feature_map1, feature_map2, feature_map3, feature_map4), dim=1)
# print(f"concatenated_features.shape",concatenated_features.shape)
# 使用SE模块进行融合
fused_feature_map = se_module(concatenated_features)

# print(fused_feature_map.shape)  # 输出融合后特征图的形状

class SEBlock(nn.Module):
    def __init__(self, in_channels, reduction_ratio=16):
        super(SEBlock, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool3d(1)

        # Channel squeeze
        self.fc1 = nn.Linear(in_channels, in_channels // reduction_ratio)
        self.relu = nn.ReLU(inplace=True)

        # Spatial excitations
        self.spatial_conv = nn.Conv3d(in_channels // reduction_ratio, 2, kernel_size=1)

        # Multiple scale excitations
        self.scale_conv1 = nn.Conv3d(in_channels // reduction_ratio, 1, kernel_size=1)
        self.scale_conv2 = nn.Conv3d(in_channels // reduction_ratio, 1, kernel_size=3, padding=1)
        self.scale_conv3 = nn.Conv3d(in_channels // reduction_ratio, 1, kernel_size=5, padding=2)

    def forward(self, x):
        b, c, _, _,_ = x.size()

        # Channel squeeze
        input_x = x
        x = self.avg_pool(x).view(b, c)
        # print(x.shape)
        x = self.fc1(x)
        x = self.relu(x)

        # Spatial excitations
        spatial_att = self.spatial_conv(x.view(b, -1, 1, 1,1))

        # Multiple scale excitations
        scale_att1 = self.scale_conv1(x.view(b, -1, 1, 1,1))
        scale_att2 = self.scale_conv2(x.view(b, -1, 1, 1,1))
        scale_att3 = self.scale_conv3(x.view(b, -1, 1, 1,1))

        # Spatial attention
        spatial_att = F.softmax(spatial_att.view(b, 2, 1, 1,1), dim=1)
        x = input_x * spatial_att[:, [0], :, :]

        # Multiple scale attention
        scale_att1 = torch.sigmoid(scale_att1)
        scale_att2 = torch.sigmoid(scale_att2)
        scale_att3 = torch.sigmoid(scale_att3)
        x = x + input_x * scale_att1 + input_x * scale_att2 + input_x * scale_att3

        return x