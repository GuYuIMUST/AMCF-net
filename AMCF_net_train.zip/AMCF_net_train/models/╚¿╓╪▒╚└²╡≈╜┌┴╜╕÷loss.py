import torch
from torch.optim import Adam

# 定义损失函数和模型
loss_func1 = torch.nn.CrossEntropyLoss()
loss_func2 = torch.nn.MSELoss()
model = MyModel()

# 定义优化器
optimizer = Adam(model.parameters(), lr=0.01)

# 定义初始比例
weight_ratio = 0.5  # 初始化为相等的权重比例

# 进行训练过程
for epoch in range(num_epochs):
    for batch_data, batch_labels in data_loader:
        optimizer.zero_grad()

        # 前向传播计算损失
        output1 = model(batch_data)
        output2 = model(batch_data)

        loss1 = loss_func1(output1, batch_labels)
        loss2 = loss_func2(output2, batch_labels)

        # 计算损失的梯度
        loss1.backward(retain_graph=True)
        loss2.backward()

        # 计算每个损失函数梯度的平均值
        grad_mean1 = torch.mean(torch.cat([param.grad.flatten() for param in model.parameters()]))
        grad_mean2 = torch.mean(torch.cat([param.grad.flatten() for param in model.parameters()]))

        # 根据梯度比例动态调节权重比例
        weight_ratio = grad_mean1 / grad_mean2

        # 按比例调整损失函数的权重
        total_loss = (loss1 * weight_ratio) + loss2

        # 反向传播更新参数
        optimizer.step()
