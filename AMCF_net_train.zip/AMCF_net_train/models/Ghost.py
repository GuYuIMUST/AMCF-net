import torch
import torch.nn as nn
import torch.nn.functional as F
import math
class GhostModule(nn.Module):
    def __init__(self, inp, oup, kernel_size=1,stride=1, ratio=2, dw_size=3,  relu=True):
        super(GhostModule, self).__init__()
        self.oup = oup
        init_channels = math.ceil(oup / ratio)# wang 中间层的channel是输入层的1/2
        new_channels = init_channels*(ratio-1) # wang 输出层的channel

        self.primary_conv = nn.Sequential( # wang 普通卷积
            #nn.Conv2d(inp, init_channels, kernel_size, stride, kernel_size//2, bias=False),
           nn.Conv3d(inp, init_channels, kernel_size, stride, kernel_size // 2, bias=False),# wang 1*1的卷积用来降维
            # nn.BatchNorm2d(init_channels),
            nn.BatchNorm3d(init_channels), # wang add
            nn.ReLU(inplace=True) if relu else nn.Sequential(), )
  # cheap操作，注意利用了分组卷积进行通道分离
        self.cheap_operation = nn.Sequential( # wang 分离卷积
            #nn.Conv2d(init_channels, new_channels, dw_size, 1, dw_size//2, groups=init_channels, bias=False),
            nn.Conv3d(init_channels, new_channels, dw_size, 1, dw_size // 2, groups=init_channels, bias=False),# wang 3*3的分组卷积进行线性映射
            #nn.BatchNorm2d(new_channels),
            nn.BatchNorm3d(new_channels),# wang add
            nn.ReLU(inplace=True) if relu else nn.Sequential(),)

    def forward(self, x):
        x1 = self.primary_conv(x)  #主要的卷积操作
        x2 = self.cheap_operation(x1) # cheap变换操作
        out = torch.cat([x1,x2], dim=1) # 二者cat到一起，将x1和x2沿着通道数堆叠
        return out[:,:self.oup,:,:]  # W 只需返回需要的通道数


class GhostBottleneck(nn.Module):
    """ Ghost bottleneck w/ optional SE"""

    def __init__(self, in_chs, mid_chs, out_chs, dw_kernel_size=3, # wang 输入通道、中间通道、输出通道、最佳的卷积核大小
                 stride=1, act_layer=nn.ReLU, se_ratio=0.):
        super(GhostBottleneck, self).__init__()
        has_se = se_ratio is not None and se_ratio > 0.
        self.stride = stride

        # Point-wise expansion
        self.ghost1 = GhostModule(in_chs, mid_chs, relu=True)

        # Depth-wise convolution
        if self.stride > 1:
            #self.conv_dw = nn.Conv2d(mid_chs, mid_chs, dw_kernel_size, stride=stride,padding=(dw_kernel_size - 1) // 2,groups=mid_chs, bias=False)
            self.conv_dw = nn.Conv3d(mid_chs, mid_chs, dw_kernel_size, stride=stride, padding=(dw_kernel_size - 1) // 2,groups=mid_chs, bias=False)
            #self.bn_dw = nn.BatchNorm2d(mid_chs)
            self.bn_dw = nn.BatchNorm3d(mid_chs) # wang add
        # Squeeze-and-excitation
        if has_se:
            self.se = SqueezeExcite(mid_chs, se_ratio=se_ratio)
        else:
            self.se = None

        # Point-wise linear projection
        self.ghost2 = GhostModule(mid_chs, out_chs, relu=False)

        # shortcut
        if (in_chs == out_chs and self.stride == 1):
            self.shortcut = nn.Sequential()
        else:
            self.shortcut = nn.Sequential(
                # nn.Conv2d(in_chs, in_chs, dw_kernel_size, stride=stride,
                #           padding=(dw_kernel_size - 1) // 2, groups=in_chs, bias=False),
                nn.Conv3d(in_chs, in_chs, dw_kernel_size, stride=stride,
                          padding=(dw_kernel_size - 1) // 2, groups=in_chs, bias=False), # wang add
                # nn.BatchNorm2d(in_chs),
                nn.BatchNorm3d(in_chs),# wang add
                # nn.Conv2d(in_chs, out_chs, 1, stride=1, padding=0, bias=False),
                nn.Conv3d(in_chs, out_chs, 1, stride=1, padding=0, bias=False),
                # nn.BatchNorm2d(out_chs),
                nn.BatchNorm3d(out_chs),# wang add
            )

    def forward(self, x):
        residual = x

        # 1st ghost bottleneck
        x = self.ghost1(x)

        # Depth-wise convolution
        if self.stride > 1:
            x = self.conv_dw(x)
            x = self.bn_dw(x)

        # Squeeze-and-excitation
        if self.se is not None:
            x = self.se(x)

        # 2nd ghost bottleneck
        x = self.ghost2(x)

        x += self.shortcut(residual)
        return x
