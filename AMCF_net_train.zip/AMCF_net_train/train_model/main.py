'''Train CIFAR10 with PyTorch.'''
#liu 数据集划分8:1:1 交叉熵损失
from __future__ import print_function

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.backends.cudnn as cudnn

import transforms as transforms
from dataloader import lunanod
import os
import argparse
import time
#from models.cnn_res import *
# from utils import progress_bar
from torch.autograd import Variable
import logging
import numpy as np
import ast
import random#liug
#from models.cnn_res_aff import *#liu
from models.moganet_3D_G_Ghost_ASFF_BCE_Focal_loss  import  FocalLoss, MogaNet
from tensorboardX import SummaryWriter # W ,在后面调用的时候用到
# from models.fusion_3d import *


parser = argparse.ArgumentParser(description='PyTorch CIFAR10 Training')
parser.add_argument('--lr', default=0.0002, type=float, help='learning rate')# Wang ,学习率
parser.add_argument('--batch_size', default=8, type=int, help='batch size ') # wang batch_size设置的大小
parser.add_argument('--resume', '-r', action='store_true', help='resume from checkpoint') # W，从断点处开始继续训练模型
parser.add_argument('--savemodel', type=str, default='', help='resume from checkpoint model')
parser.add_argument("--gpuids", type=str, default='0', help='use which gpu')#wang ,就1个GPU，所以这块等于0
parser.add_argument('--num_epochs', type=int, default=200) # W，训练的轮数
parser.add_argument('--num_epochs_decay', type=int, default=70) # wang 后70轮进行学习率递减

parser.add_argument('--num_workers', type=int, default=0)#liu 改为0 指用来加载数据的子进程。默认值是0，意味只用主进程加载数据。

parser.add_argument('--beta1', type=float, default=0.5)  # momentum1 in Adam
parser.add_argument('--beta2', type=float, default=0.999)  # momentum2 in Adam
parser.add_argument('--lamb', type=float, default=1, help="lambda for loss2")

# W，对于预训练权重应该是用不到两个参数
parser.add_argument('--fold_validate', type=int, default=3, help="fold for validate")  # guyu 实际上用的是 5
parser.add_argument('--fold_test', type=int, default=5, help="fold for test")  # guyu #liu 找一个远离subset5,6的subset训练7：验证2：测试1
# parser.add_argument('--fold_validate', type=int, default=3, help="fold for validate")
# parser.add_argument('--fold_test', type=int, default=5, help="fold for test")
# liu 12.6验证集和测试集对调 验证集为3，测试集为5

args = parser.parse_args()

# W，设置随机种子，以实现每次跑的结果相同
def setup_seed(seed):
    torch.manual_seed(seed) # W，手动设置种子
    torch.cuda.manual_seed_all(seed) # W，将手动设置的种子加载在GPU上
    np.random.seed(seed) # W，随机设置种子
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
# 设置随机数种子
setup_seed(64)#wang,设置的随机种子可以换取任意数

CROPSIZE = 32 # W，图形被裁剪成的长度
gbtdepth = 1 #liu gbt步长
# fold = args.fold
fold_validate = args.fold_validate # W，指定验证集是哪个
fold_test = args.fold_test # W，指定测试集是哪个
blklst = []#liu blklst[]是空列表 ，这里面应该装的是.npy里面除去“-”的内容 # ['1.3.6.1.4.1.14519.5.2.1.6279.6001.121993590721161347818774929286-388', \
# '1.3.6.1.4.1.14519.5.2.1.6279.6001.121993590721161347818774929286-389', \
# '1.3.6.1.4.1.14519.5.2.1.6279.6001.132817748896065918417924920957-660']
logging.basicConfig(filename='log-' + str(fold_validate), level=logging.INFO) # W，指定日志的文件名log-3

use_cuda = torch.cuda.is_available()
best_acc = 0  # wang ，best validate accuracy，主要在测试集里面用到
best_acc_gbt = 0 # W，在validate里面用到

# W，这里面可以设置起始训练的epoch，因为这里面使用了断点训练
start_epoch = 0  # start from epoch 0 or last checkpoint epoch #liu 这里可以使用断点续传

best_epoch = 0 #guyu add #liu 最高验证集准确率对应的epoch

# Cal mean std
preprocesspath = r'D:/LiuJiaqi/NAS-Lung-master-new/data/media/jehovah/Work/data/LUNA/cls/crop_v3'#liu 改路径 2021.7.20 #liu .npy类型
pixvlu, npix = 0, 0
for fname in os.listdir(preprocesspath):#liu 读入crop_v3内容
    # print(fname)
    if fname[:-4] in blklst: continue
    if fname.endswith('.npy'):
                data = np.load(os.path.join(preprocesspath, fname))
                pixvlu += np.sum(data)  #liu 计算pixvlu
                npix += np.prod(data.shape) #liu 计算npix
pixmean = pixvlu / float(npix)    #liu 计算 pixmean  mean平均值
#print(pixmean)
pixvlu = 0
for fname in os.listdir(preprocesspath):
    if fname.endswith('.npy'):
        if fname[:-4] in blklst: continue
        data = np.load(os.path.join(preprocesspath, fname)) - pixmean
        pixvlu += np.sum(data * data)
pixstd = np.sqrt(pixvlu / float(npix))  #liu sqrt 开根号 計算標準差
# pixstd /= 255
print(pixmean, pixstd)#liu 打印輸出
logging.info('mean ' + str(pixmean) + ' std ' + str(pixstd))  #liu logging info:输出信息

# Datatransforms
logging.info('==> Preparing data..')  # Random Crop, Zero out, x z flip, scale, #liu 这里读入预处理数据，经过了裁剪，清零，x、z翻轉等
transform_train = transforms.Compose([      #liu train
    # transforms.RandomScale(range(28, 38)),
    transforms.RandomCrop(32, padding=4),#liu 随机长宽比裁剪
    transforms.RandomHorizontalFlip(),#liu 随机水平翻转
    transforms.RandomYFlip(),
    transforms.RandomZFlip(),
    transforms.ZeroOut(4),
    transforms.ToTensor(),
    transforms.Normalize((pixmean), (pixstd)),  # need to cal mean and std, revise norm func
])#liu 将pixmean.pixstd里面的图像根据均值標準差等进行归一化处理

#transform_test = transforms.Compose([
transform_validate = transforms.Compose([#liu 将test改为validate
    transforms.ToTensor(),
    transforms.Normalize((pixmean), (pixstd)),
])

# load data list
trfnamelst = [] # W，train file name list
trlabellst = [] # W，train label list
trfeatlst = []  # W，train feat list
valfnamelst = [] # W，validate file name list
vallabellst = [] # W，validatelable list
valfeatlst = []  #  W，validate feat list

import pandas as pd
# W ,读入数据
dataframe = pd.read_csv('../data/annotationdetclsconvfnl_v3.csv',#liu 改路径 2021.7.20
                        names=['seriesuid', 'coordX', 'coordY', 'coordZ', 'diameter_mm', 'malignant'])
# W，将结节的信息加入到对应的文件中，准备在后续使用
alllst = dataframe['seriesuid'].tolist()[1:]
labellst = dataframe['malignant'].tolist()[1:]
crdxlst = dataframe['coordX'].tolist()[1:]
crdylst = dataframe['coordY'].tolist()[1:]
crdzlst = dataframe['coordZ'].tolist()[1:]
dimlst = dataframe['diameter_mm'].tolist()[1:] # W，结节直径大小
# test id
validate_idlst = [] #liu validate
for fname in os.listdir('D:/LiuJiaqi/NAS-Lung-master-new/data/media/jehovah/Work/data/LUNA/rowfile/subset' + str(fold_validate) + '/'):#liu 改路径 2021.7.20
    # W，将验证集的数据读在一起
    if fname.endswith('.mhd'):#liu subset以.mhd結尾
        validate_idlst.append(fname[:-4]) #liu 除了倒数第四个数取全部

# guyu 增加测试集
test_idlst = []
for fname in os.listdir('D:/LiuJiaqi/NAS-Lung-master-new/data/media/jehovah/Work/data/LUNA/rowfile/subset' + str(fold_test) + '/'):  # guyu liu 改路径 2021.7.20
    # W，# W，将测试集的数据读在一起
    if fname.endswith('.mhd'):  # liu subset以.mhd結尾
        test_idlst.append(fname[:-4])  # liu 除了倒数第四个数取全部

#2021.11.30添加第二个for语句，选两个subset作为验证集（fold+1），选择fold5为验证集，3为测试集，其余作为训练集
mxx = mxy = mxz = mxd = 0
# W，srsid：结节的序列；label:结节的良恶性；x, y, z：结节的坐标；d:结节的直径
for srsid, label, x, y, z, d in zip(alllst, labellst, crdxlst, crdylst, crdzlst, dimlst):
    mxx = max(abs(float(x)), mxx)
    mxy = max(abs(float(y)), mxy)
    mxz = max(abs(float(z)), mxz)
    mxd = max(abs(float(d)), mxd)
    if srsid in blklst: continue
    # crop raw pixel as feature
    data = np.load(os.path.join(preprocesspath, srsid + '.npy'))#liu preprocesspath，后缀为npy,将两个路径进行拼接，但是为啥两个路径一样呢？？不理解
    bgx = int(data.shape[0] / 2 - CROPSIZE / 2)
    bgy = int(data.shape[1] / 2 - CROPSIZE / 2)
    bgz = int(data.shape[2] / 2 - CROPSIZE / 2)
    data = np.array(data[bgx:bgx + CROPSIZE, bgy:bgy + CROPSIZE, bgz:bgz + CROPSIZE])
    y, x, z = np.ogrid[-CROPSIZE / 2:CROPSIZE / 2, -CROPSIZE / 2:CROPSIZE / 2, -CROPSIZE / 2:CROPSIZE / 2]
    mask = abs(y ** 3 + x ** 3 + z ** 3) <= abs(float(d)) ** 3#liu 计算mask
    feat = np.zeros((CROPSIZE, CROPSIZE, CROPSIZE), dtype=float)#liu 在这里定义feat
    feat[mask] = 1
    # print(feat.shape)
    if srsid.split('-')[0] in validate_idlst:
        valfnamelst.append(srsid + '.npy')
        vallabellst.append(int(label))
        valfeatlst.append(feat)
    elif srsid.split('-')[0] in test_idlst:
        pass
    else:  # test list 之外的，都放在train中
        trfnamelst.append(srsid + '.npy')
        trlabellst.append(int(label))
        trfeatlst.append(feat)
for idx in range(len(trfeatlst)):
    # trfeatlst[idx][0] /= mxx
    # trfeatlst[idx][1] /= mxy
    # trfeatlst[idx][2] /= mxz
    trfeatlst[idx][-1] /= mxd
for idx in range(len(valfeatlst)):
    # tefeatlst[idx][0] /= mxx
    # tefeatlst[idx][1] /= mxy
    # tefeatlst[idx][2] /= mxz
    valfeatlst[idx][-1] /= mxd
trainset = lunanod(preprocesspath, trfnamelst, trlabellst, trfeatlst, train=True, download=True,
                   transform=transform_train) # W，trainset与validateset相当于水流，而trainloader与validateloader相当于水管，一个batch一个batch的输出

trainloader = torch.utils.data.DataLoader(trainset, batch_size=args.batch_size, shuffle=True, num_workers=0,drop_last=True)#liu brokenpiperror 将num_workers改为0


validateset = lunanod(preprocesspath, valfnamelst, vallabellst, valfeatlst, train=False, download=True,
                  transform=transform_validate)
validateloader = torch.utils.data.DataLoader(validateset, batch_size=args.batch_size, shuffle=False, num_workers=0,)#liu brokenpiperror 将num_workers改为0
savemodelpath = '../checkpoint-' + str(fold_validate) + '/'#liu 模型保存路径
# Model
print(args.resume)
if args.resume: # W，文本网络训练的时候应该是这条路
    print('==> Resuming from checkpoint..')
    print(args.savemodel) # W，此时输出checkpoint
    if args.savemodel == '': # W ,此时执行这条路
        logging.info('==> Resuming from checkpoint..')
        assert os.path.isdir(savemodelpath), 'Error: no checkpoint directory found!'
        checkpoint = torch.load(savemodelpath + 'ckpt.t7') # W，这里先形成文件，之后在加载到这个文件里面
    else:
        logging.info('==> Resuming from checkpoint..')
        assert os.path.isdir(savemodelpath), 'Error: no checkpoint directory found!'
        checkpoint = torch.load(args.savemodel)
    net = checkpoint['net']
    best_acc = checkpoint['acc']
    start_epoch = checkpoint['epoch']
    print(savemodelpath + " load success")
    print(start_epoch) # W，不间断的训练时，start_epoch=0
else: # W ,执行这一条路线
    logging.info('==> Building model..')
    logging.info('args.savemodel : ' + args.savemodel)
    net = MogaNet()
    if args.savemodel != "": # W，不执行这条路
        checkpoint = torch.load(args.savemodel)
        finenet = checkpoint
        Low_rankmodel_dic = net.state_dict()
        finenet = {k: v for k, v in finenet.items() if k in Low_rankmodel_dic}
        Low_rankmodel_dic.update(finenet)
        net.load_state_dict(Low_rankmodel_dic)
        print("net_loaded")

lr = args.lr


def get_lr(epoch):#liu 获得learning rate，并进行递减
    global lr
    if (epoch + 1) > (args.num_epochs - args.num_epochs_decay):
        lr -= (lr / float(args.num_epochs_decay))
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr
        print('Decay learning rate to lr: {}.'.format(lr))


if use_cuda:#liu 使用gpu
    net.cuda()
    #if args.gpuids == 0:#liu
    if args.gpuids == 'all':
        device_ids = range(torch.cuda.device_count())
    else:
        #device_ids = map(int, list(filter(str.isdigit, args.gpuids)))
        device_ids = list(map(int, list(filter(str.isdigit, args.gpuids))))#liu add list()

    print('gpu use' + str(device_ids))
   #  net = torch.nn.DataParallel(net, device_ids=device_ids) #liu 并行计算，联想机箱只有一个gpu，把这行注释掉，等到了集群再取消注释
    #liu net = torch.nn.DataParallel(net, device_ids=device_ids)不用注释了
    cudnn.benchmark = False  # True
criterion1 = nn.BCELoss()
criterion2 =FocalLoss(gamma=2, alpha=None)
# criterion = nn.CrossEntropyLoss()#liu 交叉熵损失作为损失函数
optimizer = optim.Adam(net.parameters(), lr=args.lr, betas=(args.beta1, args.beta2)) #liu adam优化器，deeplung用的SGD
#optimizer = optim.AdamW(net.parameters(), lr=args.lr, betas=(args.beta1, args.beta2)) # wang add

# L2Loss = torch.nn.MSELoss()
def update_weight_1(epoch):
    max_epoch = args.num_epochs  # 最大训练轮数
    min_weight = 0.1  # 最小权重值
    max_weight = 0.9  # 最大

    # 使用线性增加方式更新权重
    weight_range = max_weight - min_weight # W ，weight_range=0.8
    increment_rate = epoch / max_epoch # increment_rate = epoch / 200
    new_weight_1 = min_weight + increment_rate * weight_range # W，0.1 + epoch/0.8

    return new_weight_1

def update_weight_2(epoch):
    max_epoch = args.num_epochs  # 最大训练轮数
    min_weight = 0.1  # 最小权重值
    max_weight = 0.9  # 最大权重值

    # 使用线性衰减方式更新权重
    weight_range = max_weight - min_weight  # W ,weight_range = 0.8
    decay_rate = (max_epoch - epoch) / max_epoch  # W ,decay_rate = （200-epoch）/200
    new_weight_2 = min_weight + decay_rate * weight_range # W ,0.1 + （200-epoch）/200 *0.8

    return new_weight_2
# Training
def train(epoch, loss_x):#liu 训练epoch
    logging.info('\nEpoch: ' + str(epoch))
    net.train()
    get_lr(epoch)
    train_loss = 0
    correct = 0
    total = 0
    # W ,这里面的inputs是一个tensor，targets也是一个tensor
    for batch_idx, (inputs, targets, feat) in enumerate(trainloader):#enumerate迭代，# W，其实这里和feat一点关系都没有
        if use_cuda:
            # print(inputs.shape)
            inputs, targets = inputs.cuda(), targets.cuda()
            # print(inputs)

        optimizer.zero_grad()#liu 梯度为0
        inputs, targets = Variable(inputs), Variable(targets)
        outputs1,outputs2 = net(inputs)
        loss1i = 0
        loss2i = 0
        for i in range(0,4):
            _, predict1 = torch.max(outputs2[i].data, 1)
            predict1 = torch.sigmoid(predict1).requires_grad_(True)
            loss1i += criterion1(predict1,targets.float())
            loss2i += criterion2(outputs2[i], targets)
        _, predict2 = torch.max(outputs1.data, 1)
        predict2 = torch.sigmoid(predict2).requires_grad_(True)
        loss3 = criterion1(predict2, targets.float())
        loss4 = criterion2(outputs1, targets)
        loss =update_weight_1(epoch)*loss1i+update_weight_2(epoch)*loss2i+update_weight_1(epoch)*loss3+update_weight_2(epoch)*loss4
        # loss1 = criterion(outputs2[0], targets)
        # loss2 = criterion(outputs2[1], targets)
        # loss3 = criterion(outputs2[2], targets)
        # loss4 = criterion(outputs2[3], targets)
        # loss5 = criterion(outputs1, targets)
        # loss= loss1 + loss2 + loss3 + loss4+loss5
        # loss =update_weight_2(epoch)*loss1+update_weight_1(epoch)*loss2#liu AttributeError: 'tuple' object has no attribute 'log_softmax'
       # print(loss)wangzhanju
        loss.backward()#liu loss回传
        optimizer.step() #liu 更新 Adam 随机梯度下降
        train_loss += loss.data.item() # W，item（）取出张量具体位置的元素元素值
        _, predicted = torch.max(outputs1.data, 1)#max()函数输出两个值，一个是最大值的索引值“-”，另一个值是最大值predicted
        # print(f"outputs.data", outputs.data)
        total += targets.size(0) # W ,0代表返回返回该targets二维矩阵的行数
        correct += predicted.eq(targets.data).cpu().sum()
        # print(f"correct",correct)
    print('ep ' + str(epoch) + ' tracc ' + str(correct.data.item() / float(total)) + ' lr ' + str(lr) + ' loss ' + str(train_loss))
    logging.info(
        'ep ' + str(epoch) + ' tracc ' + str(correct.data.item() / float(total)) + ' lr ' + str(lr))
    loss_x = loss_x + 1
    writer.add_scalar('train_loss', loss, global_step=loss_x)
def validate(epoch,loss_x2):#liu 这里的测试实际上为验证，11.30
    epoch_start_time = time.time()
    global best_acc
    global best_acc_gbt
    global best_epoch  # guyu 增加，说明best_epoch是外部变量
    net.eval()
    #test_loss = 0
    validate_loss = 0
    correct = 0
    total = 0
    TP = FP = FN = TN = 0 #liu 真阳性，假阳性，...
    for batch_idx, (inputs, targets, feat) in enumerate(validateloader):
    #for batch_idx, (inputs, targets, feat) in enumerate(testloader):#liu
        if use_cuda:
            inputs, targets = inputs.cuda(), targets.cuda()

        inputs, targets = Variable(inputs, requires_grad=False), Variable(targets)
        outputs1,output2 = net(inputs)

        # _, predicted = torch.max(outputs.data, 1)
        loss1i = 0
        loss2i = 0
        for i in range(0, 4):
            _, predict1 = torch.max(output2[i].data, 1)
            predict1 = torch.sigmoid(predict1).requires_grad_(True)
            loss1i += criterion1(predict1, targets.float())
            loss2i += criterion2(output2[i], targets)
        _, predict2 = torch.max(outputs1.data, 1)
        predict2 = torch.sigmoid(predict2).requires_grad_(True)
        loss3 = criterion1(predict2, targets.float())
        loss4 = criterion2(outputs1, targets)
        loss = update_weight_1(epoch) * loss1i + update_weight_2(epoch) * loss2i +update_weight_1(epoch)*loss3+update_weight_2(epoch)*loss4
        # loss1 = criterion(output2[0], targets)
        # loss2 = criterion(output2[1], targets)
        # loss3 = criterion(output2[2], targets)
        # loss4 = criterion(output2[3], targets)
        # loss5 = criterion(outputs1, targets)
        # loss = loss1 + loss2 + loss3 + loss4+loss5
        # print(f"outputs[0]",outputs[0])

        # loss = criterion(outputs, targets)#liu AttributeError: 'tuple' object has no attribute 'log_softmax'
        validate_loss += loss.data.item()#liu 应为validate
        _, predicted = torch.max(outputs1.data, 1)#liu AttributeError: 'tuple' object has no attribute 'data'
        total += targets.size(0)
        correct += predicted.eq(targets.data).cpu().sum()

        TP += ((predicted == 1) & (targets.data == 1)).cpu().sum()
        TN += ((predicted == 0) & (targets.data == 0)).cpu().sum()
        FN += ((predicted == 0) & (targets.data == 1)).cpu().sum()
        FP += ((predicted == 1) & (targets.data == 0)).cpu().sum()

    # Save checkpoint.
    acc = 100. * correct.data.item() / total#liu 计算准确率
    # if acc > best_acc:
    #     logging.info('Saving..')
    #     state = {
    #         'net': net,
    #         'acc': acc,
    #         'epoch': epoch,
    #     }
    #     if not os.path.isdir(savemodelpath):# W，os.path.isdir()判断是否是一个文件路径，在前面已经建立过了
    #         os.mkdir(savemodelpath) # W ,建立一个文件夹
    #     torch.save(state, savemodelpath + 'ckpt.t7') # W，保存预训练好的模型
    #     best_acc = acc
        #best_epoch = epoch  # liu add
    logging.info('Saving..')
    state = {
        'net': net,
        'acc': acc,
        'epoch': epoch,
    }
    if not os.path.isdir(savemodelpath):
        os.mkdir(savemodelpath)
    # if epoch % 50 == 0:
    torch.save(state, savemodelpath + 'ckpt' + str(epoch) + '.t7')
    #print(best_epoch)  # liu add
    # best_acc = acc
    tpr = 100. * TP.data.item() / (TP.data.item() + FN.data.item())
    fpr = 100. * FP.data.item() / (FP.data.item() + TN.data.item())
    tnr = 100. * TN.data.item() / (TN.data.item() + FP.data.item())  # liu add tnr特异性
    fnr = 100. * FN.data.item() / (TP.data.item() + FN.data.item())  # liu add fnr
    # precision = 100. *TP.data.item() / (TP.data.item() + FP.data.item())#liu add precision
    F1score = 100. * (TP.data.item() + TP.data.item()) / (
    TP.data.item() + TP.data.item() + FN.data.item() + FP.data.item())  # liu add f1score
    Accuracy = 100. * (TP.data.item() + TN.data.item()) / (
    TP.data.item() + TN.data.item() + FN.data.item() + FP.data.item())
    Gmean = np.sqrt(tpr * tnr)  # liu?

    #print('teacc ' + str(acc) + ' bestacc ' + str(best_acc))
    print('valacc ' + str(acc) + ' bestacc ' + str(best_acc))#liu 这里的测试实为验证，为防止以后记忆模糊，将teacc改为valacc 2021.11.30
    print('tpr ' + str(tpr) + ' fpr ' + str(fpr))
    print('tnr ' + str(tnr) + ' fnr ' + str(fnr))  # liu add

    # print('precision ' + str(precision))#liu add 11.25
    print('F1score ' + str(F1score))  # liu add
    print('Accuracy ' + str(Accuracy))  # liu add
    print('Gmean' + str(Gmean))  # liu ?
    print('val_loss' + str(validate_loss))  # liu ?

    loss_x2 = loss_x2 + 1
    writer.add_scalar('Val_loss', validate_loss, loss_x2)
    print('Time Taken: %d sec' % (time.time() - epoch_start_time))

    logging.info(
        'valacc ' + str(acc) + ' bestacc ' + str(best_acc))#liu 这里的测试实为验证，为防止以后记忆模糊，将teacc改为valacc 2021.11.30
        #'teacc ' + str(acc) + ' bestacc ' + str(best_acc))
    logging.info(
        'tpr ' + str(tpr) + ' fpr ' + str(fpr))
    logging.info(
        'tnr ' + str(tnr) + ' fnr ' + str(fnr))#liu add
    logging.info(
        'F1score ' + str(F1score))#liu add
    logging.info(
        'Accuracy ' + str(Accuracy))  # liu add
    logging.info(
        'Gmean' + str(Gmean))  # liu add
    #logging.info('best_epoch ' + str(best_epoch))  # liu add
if __name__ == '__main__':
    # W ,下面是增加tensorboard的过程
    save_dir = r'D:\WangNan\the_second_paper\NAS_Lung_master_Moganet_nomal_train'
    writer = SummaryWriter(save_dir + '/log')
    loss_x = 0  # W ,定义两个参数，并分贝传下去
    loss_x2 = 0
    for epoch in range(start_epoch + 1, start_epoch + args.num_epochs + 1):  # 200):
        train(epoch,loss_x)
        validate(epoch,loss_x2)  # guyu 此处的test 即 validate
    logging.info('best_epoch ' + str(best_epoch))  # guyu 增加 最后输出一个准确度最高的epoch，在log文件的末尾